%% Interplanetary mission assignment
%
%     LAST UPDATED:
%      21/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%      As well as for the functions used in the script, which are all
%      loaded in folder /functions
%

close all; clear; clc;
addpath(genpath(pwd))
fig = 1;
%%
% Warning prompt
prompt = '\n Load pre-calculated workspace with porkchop plot matrix and skip grid search? Y/N [N]: ';
str = input(prompt,'s');
if isempty(str) || str == 'N' || str == 'n';
    % Porkchop plot data

    n_it = 500;                          % Number of iterations dv_matrix

    % Mission data
    planet1 = 5;
    planet2 = 4;
    planet3 = 2;
    planets = [planet1,planet2,planet3];

    % Dates
    % Departures
    DEP.Earliest = [2059 5 01 0 0 0];
    DEP.Latest   = [2069 5 01 0 0 0];

    DEP.Earliest_mjd2000 = date2mjd2000(DEP.Earliest);
    DEP.Latest_mjd2000 = date2mjd2000(DEP.Latest); 

    % Fly-by
    FB.Earliest = [2059 5 01 0 0 0];
    FB.Latest   = [2069 5 01 0 0 0];

    FB.Earliest_mjd2000 = date2mjd2000(FB.Earliest);
    FB.Latest_mjd2000 = date2mjd2000(FB.Latest); 

    % Arrival
    ARR.Earliest = [2059 5 01 0 0 0];
    ARR.Latest   = [2069 5 01 0 0 0];

    ARR.Earliest_mjd2000 = date2mjd2000(ARR.Earliest);
    ARR.Latest_mjd2000 = date2mjd2000(ARR.Latest); 

    % PorckchopData (dv_matrix) calculation; very slow for high n_it
    [Dv_min,t,dv_matrix,rp] = PorkchopData(DEP,FB,ARR,n_it,planets);

end
if str== 'Y'
    load('Workspace_500it.mat');
elseif str== 'y'
    load('Workspace_500it.mat');
end

%% Draw porkchop plot which compares the  cost of the direct  transfer with the cost of the transfer with flyby
porkchop_cfr(n_it, DEP, FB, ARR, dv_matrix);

%% New time boundaries 
% Run to generate new time boundaries; the new regions are  centered around
% the solution 'y' [mjd2000]
% 
% y = t;
% fdep = 0.3*365; ffb = 0.3*365; farr = 0.3*365;
% [DEP,FB,ARR] = iterTimes(y,fdep,ffb,farr);

%% Call PcPlot 
% Warning prompt
prompt = '\n The information of the matrix will be saved in .txt format.\n It may take a while. Continue? Y/N [N]: ';
str = input(prompt,'s');
if isempty(str) || str == 'N' || str == 'n';
    str = 'N';
end
if str== 'Y' || str== 'y'
    % Run if you want to save a .txt file with a list of all the transfers
    % computed above, ordered for delta v; very slow for high n_it
    launch = PcPlot(dv_matrix,DEP,FB,ARR,planets,rp);
end

%% Plot 3D porkchop plot (scatter) and projection
dv_desired = 40;
[SOL] = alltime_mat(dv_matrix,DEP,FB,ARR,dv_desired);
projection(dv_matrix,ARR,FB,DEP,dv_desired);

%% Parameters for GA and GLOBALsearch
param.planet1 = 5; param.planet2 = 4; param.planet3 = 2;
param.mu = astroConstants(10+param.planet2); param.Rplanet = astroConstants(20+param.planet2); param.hatm = 50;
maxyears = 4; maxtime = maxyears*365.25;
maxyearsT1 = 3; maxtimeT1 = maxyearsT1*365.25;
maxyearsT2 = 2; maxtimeT2 = maxyearsT2*365.25;
param.Dv1_max = 12; param.Dv2_max = 12;

%% GlobalSearch
GSobj = @(x)Jupiter2VenusGen(x,param);
problem = createOptimProblem('fmincon', 'objective', GSobj, 'x0', t, 'lb',...
    [date2mjd2000(DEP.Earliest),date2mjd2000(FB.Earliest),date2mjd2000(ARR.Earliest)], 'ub',...
    [date2mjd2000(DEP.Latest),date2mjd2000(FB.Latest),date2mjd2000(ARR.Latest)]);
gs = GlobalSearch;
[x_gs, dv_min, flg, og] = run(gs, problem);
fprintf('Earliest departure: %d/%d/%d\n',DEP.Earliest(3),DEP.Earliest(2),...
    DEP.Earliest(1));
fprintf('Latest departure: %d/%d/%d\n',DEP.Latest(3),DEP.Latest(2),...
    DEP.Latest(1));
fprintf('Earliest arrival: %d/%d/%d\n',ARR.Earliest(3),ARR.Earliest(2),...
    ARR.Earliest(1));
fprintf('Latest arrival: %d/%d/%d\n\n',ARR.Latest(3),ARR.Latest(2),...
    ARR.Latest(1));

arr = mjd20002date(x_gs(3));
fb  = mjd20002date(x_gs(2));
dep = mjd20002date(x_gs(1));

fprintf('Best departure date: %d/%d/%d\n',dep(3),dep(2),dep(1));
fprintf('Best flyby date: %d/%d/%d\n',fb(3),fb(2),fb(1));
fprintf('Best arrival date: %d/%d/%d\n',arr(3),arr(2),arr(1));
fprintf('Δv required: %f\n',dv_min);

%% Genetic Algorithm
% Warning prompt
prompt = '\n Running genetic algorithm.\n It may take a while. Continue? Y/N [N]: ';
str = input(prompt,'s');
if isempty(str)|| str == 'N' || str == 'n';
    str = 'N';
end
if str== 'Y' || str== 'y';
    A = [-1,1,0;0,-1,1;-1,0,1];  b = [maxtimeT1;maxtimeT2;maxtime]; Aeq = []; beq = [];
    lb = [DEP.Earliest_mjd2000,FB.Earliest_mjd2000,ARR.Earliest_mjd2000];
    ub = [DEP.Latest_mjd2000,FB.Latest_mjd2000,ARR.Latest_mjd2000];
    IntCon = []; 
    GeneticObjective = @(x)Jupiter2VenusGenVect(x,param);

    options = optimoptions(@ga,'CrossoverFraction', 0.9, 'MaxGenerations',90,'MaxStallGenerations',70,...
                           'PopulationSize',300, 'EliteCount', 8, 'FunctionTolerance', 1e-10,...
                           'PlotFcn',{@gaplotbestindiv,@gaplotscorediversity,@gaplotscores,@gaplotselection,@gaplotbestf,@gaplotrange},...
                           'UseVectorized',true,'UseParallel',true);
    tic                  
    [x_ga,Fval,exitFlag,Output] = ga(GeneticObjective,length(lb),A,b,Aeq,beq,lb,ub,[],IntCon,options);
    CPUtimeGen = toc;

    fprintf('Earliest departure: %d/%d/%d\n',DEP.Earliest(3),DEP.Earliest(2),...
        DEP.Earliest(1));
    fprintf('Latest departure: %d/%d/%d\n',DEP.Latest(3),DEP.Latest(2),...
        DEP.Latest(1));
    fprintf('Earliest arrival: %d/%d/%d\n',ARR.Earliest(3),ARR.Earliest(2),...
        ARR.Earliest(1));
    fprintf('Latest arrival: %d/%d/%d\n\n',ARR.Latest(3),ARR.Latest(2),...
        ARR.Latest(1));

    arr = mjd20002date(x_ga(3));
    fb  = mjd20002date(x_ga(2));
    dep = mjd20002date(x_ga(1));

    fprintf('Best departure date: %d/%d/%d\n',dep(3),dep(2),dep(1));
    fprintf('Best flyby date: %d/%d/%d\n',fb(3),fb(2),fb(1));
    fprintf('Best arrival date: %d/%d/%d\n',arr(3),arr(2),arr(1));
    fprintf('Δv required: %f\n',Fval);
end

%% SOLUTION CHOICE
 x = x_gs;       % globalsearch solution
% x = x_ga;     % genetic algorith solution
% x = t;        % grid search solution

%% Helioplot
figure()
Helioplot(planets,x)

%% Fly-by plot
[delta_t_in,delta_t_out,dt] = FlybyTimes(planets,param.hatm,x);
times_plot = [x,-delta_t_in,delta_t_out];
FlyBy_plot_helio (planets, times_plot);
FlyBy_plot_peri (planets, times_plot);

%% Print flyby data
flyby = flyby_charact(x,param);