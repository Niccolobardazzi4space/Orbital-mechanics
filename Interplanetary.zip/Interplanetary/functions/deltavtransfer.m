function [Dv_dep,Dv_arr,V1,V2,v_dep,v_arr] = deltavtransfer(t_dep, t_arr, planet1, planet2)

% Function to compute the total deltav for an interplanetary transfer       
% given departure and arrival dates t_dep and t_arr in MJD2000.
% Position of planet 1 and 2 at t_dep and t_arr are calculated in keplerian param.
% using 'uplanet.m' (ephemerides).
%
%     INPUTS:
%       t_dep       departure date in MJD2000
%       t_arr       arrival date in MJD2000
%       planet1
%       planet2
%         Planet of departure and arrival must be specified entering:
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%                   10:  Sun
%  
%     OUTPUTS:
%       Dv_dep      delta v required at departure [km/s]
%       Dv_arr      delta v required at arrival [km/s]
%       V1 [3,1]    velocity of s/c at departure on helio leg [km/s]
%       V2 [3,1]    velocity of s/c at arrival on helio leg [km/s]
%       v_dep [3,1]    velocity of the planet of departure [km/s]
%       v_arr [3,1]    velocity of the planet of arrival [km/s]
%
%     CALLED FUNCTIONS:
%            uplanet.m
%            kp2rv.m
%            lambertMR.m
%
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       

% Computation of time of flight

tof = (t_arr - t_dep)*24*60^2;

% Position of planet 1 and 2 

[kep_dep,ksun_dep] = uplanet(t_dep, planet1);
[kep_arr,ksun_arr] = uplanet(t_arr, planet2);

% Conversion to (r,v)

[r_dep,v_dep]=kp2rv(kep_dep(1),kep_dep(2),kep_dep(3),kep_dep(4),kep_dep(5),kep_dep(6),ksun_dep);
[r_arr,v_arr]=kp2rv(kep_arr(1),kep_arr(2),kep_arr(3),kep_arr(4),kep_arr(5),kep_arr(6),ksun_arr);

% Lambert solver for the transfer

muS = astroConstants(4);
[~,~,~,~,V1,V2,~,~] = lambertMR(r_dep,r_arr,tof,muS,0,0,0,1);
V1 = V1';
V2 = V2';

% Deltav

delta_v_1 = V1 - v_dep;
delta_v_2 = v_arr - V2;
Dv_dep = norm(delta_v_1);
Dv_arr = norm(delta_v_2);




