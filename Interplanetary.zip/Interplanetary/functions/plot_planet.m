function [figure] = plot_planet(PLANET, R, R_p)
%%
%      plot_planet.m : computes the plot of a planet as an ellipsoid
%     
%     
%     DESCRIPTION:

%           computes the plot of a planet as an ellipsoid

%     INPUT: 
%           PLANET: texture of a planisphere of a planet
%            R = position of the planet in the frame of reference
%            R_p = radius of the planet
%     
%     OUTPUT:
%           plot

%     CALLED FUNCTIONS:
%                       -----
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%      
%

props.FaceColor = 'texture';
props.EdgeColor = 'none';
props.FaceLighting = 'phong';
props.Cdata = PLANET;
C = -[R(1);R(2);R(3)];
[XX,YY,ZZ] = ellipsoid(C(1),C(2),C(3),R_p,R_p,R_p,1000);
figure = surface(-XX,-YY,-ZZ,props,'HandleVisibility','off');
hold on
axis equal

end
