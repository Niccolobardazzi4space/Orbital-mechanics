function porkchop_cfr(n_it, DEP, FB, ARR, dv_matrix)
%%    porkchop_cfr.m
%     DESCRIPTION
%       This function draws a porkchop plot which allows to compare the
%       delta v of the direct transfer and the transfer with flyby
%
%
%     INPUTS:
%       DEP[struct]     Structure with categories:
%                           -.Earliest: earliest departure vector date  [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest departure vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       FB[struct]      Structure with categories:
%                           -.Earliest: earliest flyby vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest flyby vector date          [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       ARR[struct]     Structure with categories:
%                           -.Earliest: earliest arrival vector date    [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest arrival vector date        [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       n_it[1]         Number of iterations in each dimension of the matrix [integer]
%       dv_matrix [n_it,n_it,n_it]    3D matrix containing the delta v of
%                                     the transfer with the flyby
%  
%     OUTPUTS:
%       plot
%
%     CALLED FUNCTIONS:
%            deltavtransfer1.m
%            mjd20002date.m
%
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%% Porkchop plot
window = [3,30];     % boundaries for velocity
dv_desired = 30;

%% Grid for the plot

dep_g = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, n_it);
arr_g = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, n_it);

%% For cicle to compute all possible deltav

for i=1:length(dep_g)
    t_1 = mjd20002date(dep_g(i));
    dep_dates(i) = datenum(t_1);
    arr_dates(i) = datenum(mjd20002date(arr_g(i)));
    for j=1:length(arr_g)
        t_2 = mjd20002date(arr_g(j));
        [delta_v_tot_jm(i,j), delta_v_1_jm(i,j), delta_v_2_jm(i,j)] = deltavtransfer1(t_1, t_2, 5, 2, window);
    end
end

[rows,~,deeps] = size(dv_matrix);
dv = NaN(rows,deeps);
t_dep = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, rows);
t_flyby = linspace(FB.Earliest_mjd2000, FB.Latest_mjd2000, rows);
t_arr = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, rows);

for i = 1:rows
    dates_tdep(i) = datenum(mjd20002date(t_dep(i)));
    dates_tarr(i) = datenum(mjd20002date(t_arr(i)));
    for k = 1:deeps
        a = min(dv_matrix(i,:,k));
        dv(i,k) = a;
    end
end


for i = 1:rows
    for k = 1:deeps
        if dv(i,k) ~= dv(i,k)
            dv(i,k) = NaN;       
        end
    end
end

dvmin = min(min(dv));

%% plot
figure ()
title('Porkchop plot direct vs. fly-by');
Dv_min = min(min(delta_v_tot_jm)); Dv_max = max(max(delta_v_tot_jm));
% set(gcf, 'Position',get(0,'Screensize'));
ax(1) = axes;
[C1,h1] = contour(dep_dates, arr_dates, (delta_v_tot_jm)', (floor(Dv_min):1:ceil(Dv_max)),'showtext','off');
xtickangle(45);
ytickangle(45);
datetick('x', 'yyyy mm dd','keeplimits')
datetick('y', 'yyyy mm dd','keeplimits')
xlabel('Departure date')
ylabel('Arrival date')
axis tight
% clabel(C1,h1);
colormap(ax(1),cool);
hcb = colorbar('Position',[.028 .12 .02 .815]);
ha = gca; ha.FontSize = 13; 
hcb.Title.String='$\Delta v$ direct [km/s]'; 
hcb.Title.Interpreter='latex';
grid minor


% clevels = linspace(floor(Dv_min),dv_desired,10);
ax(2) = axes;
ax(2).Visible = 'off';
[C2,h2] = contour(dep_dates, arr_dates,dv',((dvmin):1:ceil(dv_desired)),'ShowText','off');
set(gca,'xtick',[]);
set(gca,'ytick',[]);
ha = gca;
ha.FontSize = 13;
axis tight
set(ax(2), 'XAxisLocation','bottom',...
           'YAxisLocation','left',...
           'Color','none');
hcb2 = colorbar('Position',[.93 .12 .02 .815]);
hcb2.Title.String = '$\Delta v$ flyby[km/s]';
hcb2.Title.Interpreter = 'latex';
% c = jet;
% c = flipud(c);
colormap(ax(2),hot);
grid minor
end