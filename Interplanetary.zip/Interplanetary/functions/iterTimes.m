function [DEP,FB,ARR] = iterTimes(y,fdep,ffb,farr) 
%%
%      iterTimes.m -- generates new time windows
%     
%     
%     DESCRIPTION:
%       This function computes new time windows centered around  a given 
%       y = [t_dep; t_flyby; t_arr] given in MJD2000
%     
%     INPUT: 
%          y [3,1]  as written above 
%          fdep     number of days corresponding to half of the new window
%                   of departure
%          ffb      number of days corresponding to half of the new window
%                   of flyby
%          farr     number of days corresponding to half of the new window
%                   of arrival
%     
%     OUTPUT:
%       DEP[struct]     Structure with categories:
%                           -.Earliest: earliest departure vector date  [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest departure vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       FB[struct]      Structure with categories:
%                           -.Earliest: earliest flyby vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest flyby vector date          [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       ARR[struct]     Structure with categories:
%                           -.Earliest: earliest arrival vector date    [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest arrival vector date        [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%     
%     CALLED FUNCTIONS:
%      mjd20002date.m
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

% % Departures

DEP.Earliest = mjd20002date(y(1)-fdep);
DEP.Latest   = mjd20002date(y(1)+fdep);
 
DEP.Earliest_mjd2000 = y(1)-fdep;
DEP.Latest_mjd2000 = y(1)+fdep; 

% % Fly-by

FB.Earliest = mjd20002date(y(2)-ffb);
FB.Latest   = mjd20002date(y(2)+ffb);

FB.Earliest_mjd2000 = y(2)-ffb;
FB.Latest_mjd2000 = y(2)+ffb;


% Arrival

ARR.Earliest = mjd20002date(y(3)-farr);
ARR.Latest   = mjd20002date(y(3)+farr);

ARR.Earliest_mjd2000 = y(3)-farr;
ARR.Latest_mjd2000 = y(3)+farr; 

end