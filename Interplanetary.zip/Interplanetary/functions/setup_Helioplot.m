function setup_Helioplot
%% Setting for Helioplot.m
%      
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

% AU = astroConstants(2);
% plot_planet(astroConstants(3)/AU);
scatter3(0,0,0,'filled','MarkerFaceColor','r','MarkerEdgeColor','r');

title('Heliocentric Trajectory')
axis equal
xlabel('x [AU]')
ylabel('y [AU]')
zlabel('z [AU]')
grid minor
view(0,90);
hold on
end