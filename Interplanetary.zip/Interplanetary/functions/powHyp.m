function [Dvp,delta,rp,hypin,hypout] = powHyp(v8m,v8p,mu,Rplanet,hatm)
%%
%     powHyp.m - Powered fly-by computation
%     
%     
%     DESCRIPTION:
%       This function computes the radius of perigee of the hyperbolic arcs
%       for a powered fly-by manoeuvre, the delta v required and the
%       characteristics of the two arcs
%     
%     INPUT:
%       
%       v8m [3,1]    v_infinite of s/c on the incoming hyperbolic arc [km/s]
%       v8p [3,1]    v_infinite of s/c on the out-coming hyperbolic arc [km/s]
%       mu           planetary constant of the planet [km^3/s^2]
%       Rplanet      radius of the planet [km]
%       hatm         altitude of the atmosphere i.e. minimum fly-by
%                    altitude allowed [km]
%     
%     OUTPUT:
%
%       Dvp          delta_v necessary for powered fly-by [km/s]
%       delta        turning angle [rad]
%       rp           radius of perigee of the hyperbolas [km]
%       hypin        structure containing information about the incoming
%                    hyperbolic arc 
%       hypout       structure containing information about the out-coming
%                    hyperbolic arc 
%     
%     CALLED FUNCTIONS:
%      fsolve 
%       
%     LAST UPDATED:
%      02/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%

    Cosdelta = max(min(dot(v8m,v8p)/(norm(v8m)*norm(v8p)),1),-1);
    delta = real(acos(Cosdelta)); rp0 = Rplanet;
    options = optimoptions('fsolve','Display','off','FunctionTolerance',1e-16);
    rp = fsolve(@(rp) Hyp(rp,delta,v8m,v8p,mu),rp0,options);
    if rp > Rplanet + hatm
        vpm = sqrt(norm(v8m)^2+2*mu/rp);
        vpp = sqrt(norm(v8p)^2+2*mu/rp);
        Dvp = abs(vpp-vpm);
    else
        Dvp = NaN;
        vpm = NaN; vpp = NaN;
%         fprintf('Flyby not possible due to planet proximity\n.')
    end
    
    % Define hyperbolas
    hypin.a = -mu/norm(v8m)^2;                  % semi-major axis
    hypin.e = 1+rp*norm(v8m)^2/mu;              % eccentricity
    hypin.delta = 2*asin(1/hypin.e);            % turn angle
    hypin.D = -hypin.a/tan(hypin.delta/2);      % impact parameter
    hypin.h = rp*vpm;                           % angular momentum
    hypin.hvect = hypin.h*(cross(v8m,v8p)/norm(cross(v8m,v8p)));  % angular momentum vector
    hypin.vp = vpm;                             % velocity at perigee
    hypin.eccvect = cross(v8m,hypin.hvect)/mu+v8m/norm(v8m); % eccentricity vector
    
    hypout.a = -mu/norm(v8p)^2;
    hypout.e = 1+rp*norm(v8p)^2/mu;
    hypout.delta = 2*asin(1/hypout.e);
    hypout.D = -hypout.a/tan(hypout.delta/2);
    hypout.h = rp*vpp;
    hypout.hvect = hypout.h*(cross(v8m,v8p)/norm(cross(v8m,v8p)));
    hypout.vp = vpp;
    hypout.eccvect = cross(v8p,hypout.hvect)/mu-v8p/norm(v8p);
    
end
function F = Hyp(rp,delta,v8m,v8p,mu)
    em = 1+rp*norm(v8m)^2/mu;
    deltam = 2*asin(1/em);
    
    ep = 1+rp*norm(v8p)^2/mu;
    deltap = 2*asin(1/ep);
    
    F = delta-deltam-deltap;
end