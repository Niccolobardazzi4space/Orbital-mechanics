function [r_vect, r, v_vect, v] = orbit_propagation(mu, RI, VI, t0, t1, lin_step)
%% integrates the 2BP and finds position and velocity vectors and their magnitudes
% INPUTS 
%    mu = gravitational parameter of the planet
%    RI = [1 x 3] vector of initial position in cartesian coordinates
%    VI = [1 x 3] initial velocity vector in cartesian coordinates
%    t0, t1 = initial and final time
%    lin_step = number of iterations
% OUTPUTS (after integration)
%      r_vect = [lin_step; 3] ---- matrix with all position vectors 
%      r = [lin_step; 1] ---- matrix with all positions 
%      v_vect = [lin_step; 3] ---- matrix with all velocity vectors 
%      v = [lin_step; 1] ---- matrix with all velocities 
% CALLED FUNCTIONS:
%                 ode_orbit_dynamics.m
%
% LAST UPDATED:
%      20/01/2020
%
% CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
   
r0_x = RI(1);
r0_y = RI(2);
r0_z = RI(3);
v0_x = VI(1);
v0_y = VI(2);
v0_z = VI(3);
y0 = [r0_x,r0_y,r0_z;v0_x,v0_y,v0_z]';               
options = odeset('RelTol',1e-13,'AbsTol', 1e-6);
tspan = linspace(t0,t1,lin_step);
[~,Y] = ode113(@ode_orbit_dynamics,tspan,y0,options,mu);
r_vect = [Y(:,1),Y(:,2),Y(:,3)];
v_vect = [Y(:,4),Y(:,5),Y(:,6)];
v = sqrt(Y(:,4).^2+Y(:,5).^2+Y(:,6).^2);
r = sqrt(Y(:,1).^2+Y(:,2).^2+Y(:,3).^2);

end

function [dy] = ode_orbit_dynamics(~,y,mu)
rx = y(1);
ry = y(2);
rz = y(3);
vx = y(4);
vy = y(5);
vz = y(6);
r  = sqrt(rx.^2+ry.^2+rz.^2);
dy(1,1) = vx;           %velocità     dy vettore degli stati finale (velocità e accelerazione)
dy(2,1) = vy;
dy(3,1) = vz;
dy(4,1) = -mu*rx/r.^3;  %accelerazioni
dy(5,1) = -mu*ry/r.^3;
dy(6,1) = -mu*rz/r.^3;
end

