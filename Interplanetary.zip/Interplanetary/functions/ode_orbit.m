function dy = ode_orbit( ~, y, mu)
%%
%
%      ode_orbit.m - Two body problem equation
%     
%     PROTOTYPE:
%     	dy = ode_orbit( ~, y, mu)
%     
%     DESCRIPTION:
%       This function calculates the derivative of position and velocity of
%       the SC with time. Use for integration.
%     
%     INPUT:
%       y[6,1]  Vector with position and velocity of the SC [km,km/s].
%       mu[1]   Planet constant [km3/s2]
%     
%     OUTPUT:
%       dy[]    Vector with velocity and acceleration of the SC [km/s,km/s2].
%     
%     CALLED FUNCTIONS:
%       -
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    r = y(1:3); v = y(4:6);
    dy = [v;(-mu/norm(r)^3)*r];
end