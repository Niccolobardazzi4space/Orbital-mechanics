function FlyBy_plot_helio (planets, times)
%%
%     DESCRIPTION:
%       This function plots the hyperbolic arcs for a powered flyby around a
%       planet in a reference frame with the axes parallel to those of the
%       heliocentric frame and the origin shifeted at the center of the
%       planet. 
%     
%     INPUT:
%       planets[1,3]    Integer number identifying the planets of:
%       departure, flyby, arrival:
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%       times[t_dep,t_flyby,t_arrival,t_in,t_out]           Times for reaching and departing from planets, ordered
%                                                           chronologically in MJD2000 [days]. t_in is the time
%                                                           entering the sphere of influence wrt 2d hyperbola perigee
%                                                           passage; t_out is the time when the s/c leaves the
%                                                           SOI. 
%                                                           NB: t_in has to be negative for a backward
%                                                           propagation
%     
%     OUTPUT:
%       plot
%     
%     CALLED FUNCTIONS:
%       -astroConstants
%       -deltavtransfer
%       -powhyp
%       -orbit_propagation (needs 'ode_orbit_dynamics')
%       -plot_planet  (needs 'Mars.map.jpg')

%    LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.


%% constants
R = [0;0;0];                               %planet position in the plot
lin_step = 40;
mu = astroConstants(10+planets(2));
Rplanet = astroConstants(20+planets(2));   % mars radius
hatm = 50;

%% define incoming and outcoming hyperbolas
t1 = times(1); t2 = times(2); t3 = times(3);
planet1 = planets(1); planet2 = planets(2); planet3 = planets(3);
[~,~,~,V2,~,v_arr] = deltavtransfer(t1, t2, planet1, planet2);
[~,~,V1,~,~,~] = deltavtransfer(t2, t3, planet2, planet3);
v8m = V2-v_arr;
v8p = V1-v_arr;                                                 
[~,~,rp,hypin,hypout] = powHyp(v8m,v8p,mu,Rplanet,hatm);                          
Rp = real(rp);                         % radius of perigee(magnitude) 
  
%% hyperbolic arcs determination 
t0 = 0;                                                %perigee passage
t_in = times(4);
t_out = times(5);

e_direction = hypin.eccvect/norm(hypin.eccvect); % eccentricity vector direction
h_direction = hypin.hvect/hypin.h; % angular momentum vector direction
vp_direction = cross(h_direction, e_direction)/norm(cross(h_direction, e_direction));

rp_vect = Rp*e_direction;          % pericenter vector
vp1_vect = hypin.vp*vp_direction;  % velocity at pericenter vector                                                           
[r_vect1, ~, ~, ~] = orbit_propagation(mu, rp_vect, vp1_vect , t0, t_in, lin_step);
vp2_vect = hypout.vp*vp_direction;
[r_vect2, ~, ~, ~] = orbit_propagation(mu, rp_vect, vp2_vect, t0, t_out, lin_step);

%% plot

figure()
title('Powered fly-by hyperbolic arcs')
MARS = imread('Mars_map.jpg','jpg');
[mars] = plot_planet(MARS, R, Rplanet);
hold on
plot3(r_vect1(:,1), r_vect1(:,2), r_vect1(:,3),'b','LineWidth',2);
hold on
plot3(r_vect2(:,1), r_vect2(:,2), r_vect2(:,3),'c','LineWidth',2);
hold on 
plot3 (rp_vect(1), rp_vect(2), rp_vect(3), '.m','MarkerSize', 20);
hold on 
quiver3(0,0,0, 0.5*Rplanet*v_arr(1),0.5*Rplanet*v_arr(2), 0.5* Rplanet*v_arr(3),'linewidth',2);
hold on
quiver3(0,0,0,0.5*Rplanet*v8m(1),0.5*Rplanet*v8m(2),0.5*Rplanet*v8m(3),'b','linewidth',2);
hold on
quiver3(0,0,0,0.5*Rplanet*v8p(1),0.5*Rplanet*v8p(2),0.5*Rplanet*v8p(3),'c','linewidth',2);
legend ('Incoming hyperbolic branch', 'Out-coming hyperbolic branch', 'Fly-by position','Planet Velocity',...
    '$V_{\infty}-$','$V_{\infty}+$','Interpreter','latex')
xlabel('X [km]'); ylabel('Y [km]'); zlabel('Z [km]');
set(gca,'Color','k')
grid on
ax = gca;
ax.GridColor = 'w';
