function projection(mat,ARR,FB,DEP,dv_desired)
%%     
%     projection.m - plots a 2d projection of a 3d matrix 
%     
%     
%     DESCRIPTION:
%          this function takes a 3d matrix which has as elements the total delta v 
%          for every  departure, flyby and arrival time and makes a 2d
%          projection in the departure-arrival plane
%     
%     INPUT: 
%          mat = 3D matrix of dv, calculated for example with
%          porkchopData.m
%         
%          DEP = structure: earliest and latest departure dates, both in
%          dates and mjd2000 format;

%          FB = structure: earliest and latest flyby dates, both in
%          dates and mjd2000 format;

%          ARR = structure: earliest and latest arrival dates, both in
%          dates and mjd2000 format

%          dv_desired = upper boundary, exclude every value bigger than
%          this one.

%     OUTPUT:
%         plot

%     CALLED FUNCTIONS:
%                       -----
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%      

addpath(genpath(pwd))

[rows,~,deeps] = size(mat);

dv = NaN(rows,deeps);

t_dep = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, rows);
t_flyby = linspace(FB.Earliest_mjd2000, FB.Latest_mjd2000, rows);
t_arr = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, rows);

for i = 1:rows
    dates_tdep(i) = datenum(mjd20002date(t_dep(i)));
    dates_tarr(i) = datenum(mjd20002date(t_arr(i)));
    for k = 1:deeps
        a = min(mat(i,:,k));
%         tof(i,k) = t_arr(k) - t_dep(i);
        dv(i,k) = a;
    end
end


for i = 1:rows
    for k = 1:deeps
        if dv(i,k) ~= dv(i,k)
            dv(i,k) = NaN;
%             tof(i,k)= NaN;
           
        end
    end
end

dvmin = min(min(dv));


% tof = linspace(min(min(tof)),max(max(tof)),rows);
% [t_grid,dep_grid] = meshgrid(tof,dates_tdep); 


figure()
title ('Porkchop');
clevels = linspace(dvmin,dv_desired,10);
contourf(dates_tdep,dates_tarr,dv',clevels,'ShowText','off');
xtickangle(45)
ytickangle(45)
datetick('x', 'dd mmm yyyy','keeplimits')
datetick('y', 'dd mmm yyyy','keeplimits')
xlabel('Departure date')
ylabel('Arrival date')
hcb = colorbar;
hcb.Title.String = '$\Delta v$ [km/s]';
hcb.Title.Interpreter = 'latex';
ha = gca;
ha.FontSize = 13;
hcb.Title.FontSize = 15;
axis tight
grid minor
c = jet;
c = flipud(c);
colormap(c);

end