function delta_t12 = delta_t_hyp(e, h, theta1, theta2, planet)
%%
%     delta_t_hyp.m 
%     
%     
%     DESCRIPTION:
%       This function computes the time it takes to go from point 1 to point 2 on
%       a hyperbolic trajectory
%     
%     INPUT:
%       
%       e = eccentrycity of the orbit [-]
%       h = angular momentum of the orbit [km^2/s]
%       theta1, theta2 = true anomalies of point 1 and 2 [rad]
%       planet = central body 
%        Planets are numbered as follows:
%           1  Me      
%           2  V       
%           3  E       
%           4  Ma      
%           5  J       
%           6  S       
%           7  U       
%           8  N       
%           9  P       
%           0  Moon    
%     
%     OUTPUT:
%       delta_t12 = time from theta1 to theta2 [sec]
%      
%    
%     CALLED FUNCTIONS:
%      astroConstants.m
%       
%     LAST UPDATED:
%      10/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%

mu = astroConstants(10 + planet); % [km^3/s^2]

% Hyperbolic eccentric  anomalies
F1 = 2*atanh(sqrt((e-1)/(e+1))*tan(theta1/2));

F2 = 2*atanh(sqrt((e-1)/(e+1))*tan(theta2/2));

% Mean anomalies
Mh1 = e*sinh(F1) - F1;

Mh2 = e*sinh(F2) - F2;

% Times from perigee passage (seconds)
t1 = (h^3)/(mu^2)*1/((e^2-1)^(3/2))*Mh1;

t2 = (h^3)/(mu^2)*1/((e^2-1)^(3/2))*Mh2;

% Delta t

delta_t12 = t2 - t1;