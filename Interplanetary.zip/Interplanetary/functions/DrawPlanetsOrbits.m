function DrawPlanetsOrbits(planets,times)
%%
%      DrawPlanetsOrbits.m - Heliocentric transfer plot
%     
%     PROTOTYPE:
%     	DrawPlanetsOrbits(planets,times)
%     
%     DESCRIPTION:
%       This function plots on a preexisting figure the heliocentric orbit os selected planets.
%     
%     INPUT:
%       planets[1,N]    Integer number identifying the planets for transfer in 
%                       the order they are visited
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%       times[1,N]      Times for reaching and departing from planets, ordered
%                       chronologically in MJD2000 [days]
%     
%     OUTPUT:
%       plot
%     
%     CALLED FUNCTIONS:
%       astroConstants.m
%       kp2rv.m
%
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%    
N = 1; %Points/24h
AU = astroConstants(2);
points = ceil((times(end)-times(1))/N);
R0 = zeros(1,points);
legtext = findobj(legend).String;
for i=1:length(planets)
    for j=1:points
        t = times(1)+(times(end)-times(1))/points*(j-1);
        [kep0, muS] = uplanet (t, planets(i));
        [R0(1:3,j),~]=kp2rv(kep0(1),kep0(2),kep0(3),kep0(4),kep0(5),kep0(6),muS);
    end
    hold on
    plot3(R0(1,:)/AU,R0(2,:)/AU,R0(3,:)/AU,'Linewidth',2)
    legtext = [legtext,{strcat('Orbit of planet ',string(i))}];
    legend(legtext);
    for k = 1:length(times)
        [kep0, muS] = uplanet (times(k), planets(i));
        [rpl(1:3,1),~]=kp2rv(kep0(1),kep0(2),kep0(3),kep0(4),kep0(5),kep0(6),muS);
        hold on
        scatter3(rpl(1,1)/AU,rpl(2,1)/AU,rpl(3,1)/AU,55,'Linewidth',2);
        legtext = [legtext,{strcat('Planet  ',string(i),' position at ',string(datetime(mjd20002date(times(k)))))}];
    end
end
legend(legtext)
end