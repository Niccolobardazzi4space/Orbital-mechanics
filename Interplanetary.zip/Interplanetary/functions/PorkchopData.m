function [Dv_min,y,dv,rp] = PorkchopData(DEP,FB,ARR,n_it,planets)
%
%      PorkchopData.m - Grid Search 
%     
%     PROTOTYPE:
%     	[Dv_min,y,dv,rp] = PorkchopData(DEP,FB,ARR,n_it,planets)
%     
%     DESCRIPTION:
%       This function carries out a grid search for the transfer between the selected 
%       planets and dates. It admits three planets and carries out a flyby
%       in the middle planet.
%     
%     INPUT:
%       DEP[struct]     Structure with categories:
%                           -.Earliest: earliest departure vector date  [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest departure vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       FB[struct]      Structure with categories:
%                           -.Earliest: earliest flyby vector date      [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest flyby vector date          [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       ARR[struct]     Structure with categories:
%                           -.Earliest: earliest arrival vector date    [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Latest: latest arrival vector date        [yyyy,mm,dd,hh,mm,ss.sss]
%                           -.Earliest_mjd2000: .Earliest in MJD2000    [days]
%                           -.Latest_mjd2000: .Latest in MJD2000        [days]
%       n_it[1]         Number of iterations in each dimension of the matrix [integer]
%       planets[1,3]    Vector with three planets in visiting order.
%                       Planets are numbered as follows:
%           1  Me      
%           2  V       
%           3  E       
%           4  Ma      
%           5  J       
%           6  S       
%           7  U       
%           8  N       
%           9  P       
%           0  Moon    
%     
%     OUTPUT:
%       Dv_min [1]          Minimum dv needed to perform the transfer 
%                           within the calculated times [km/s].
%       y [1,3]             Dates at which min dv occurs in MJD2000 [days]
%       dv [n_it,n_it,n_it] Matrix of dv for the dates in equally spaced 
%                           vectors from earlies to latest, in order of 
%                           departure, flyby,arrival [km/s]
%       rp [1]              Radius of the perigee of the flyby hyperbola [km]
%     
%     CALLED FUNCTIONS:
%       deltavtransfer.m
%       mjd20002date.m
%       astroConstants.m
%       powHyp
%       ind2sub
%       

fprintf('Running PorckchopData, please wait while matrix is computed.\n')

t_dep = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, n_it);
t_flyby = linspace(FB.Earliest_mjd2000, FB.Latest_mjd2000, n_it);
t_arr = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, n_it);

planet1 = planets(1);
planet2 = planets(2);
planet3 = planets(3);

mu = astroConstants(10+planet2);
Rplanet = astroConstants(20+planet2);
hatm = 50;

dates_tdep = zeros(length(t_dep),1);
dates_tarr = zeros(length(t_dep),1);
dv = zeros(n_it,n_it,n_it);
Dv_flyby = NaN(n_it,n_it,n_it);
rp = NaN(n_it,n_it,n_it);

tof_min1 = 480;   % parabolic time of first transfer
tof_max1 = 1200;  % Hohmann transfer time for first transfer

tof_min2 = 80;    % parabolic time of first transfer
tof_max2 = 250;   % transfer time for first transfer

window1 = [4,12];   % reasonable boundaries for velocity for first transfer
window2 = [4.5,12]; % reasonable boundaries for velocity for second transfer


for k1 = 1:length(t_dep)
    
    dates_tdep(k1) = datenum(mjd20002date(t_dep(k1)));
    dates_tarr(k1) = datenum(mjd20002date(t_arr(k1)));
    
    for k2 = 1:length(t_flyby)
        
        t1 = t_dep(k1);
        t2 = t_flyby(k2);
        if t2 <= t1 || (t2-t1) < tof_min1 || (t2-t1) > tof_max1 
            dv(k1,k2,:) = NaN;
            
        else
            [Dv_dep1,~,~,V2,~,v_arr] = deltavtransfer(t1, t2, planet1, planet2);
            if Dv_dep1 < window1(1) || Dv_dep1 > window1(2)
                dv(k1,k2,:) = NaN;
            else
                for k3 = 1:length(t_arr)
                
                t3 = t_arr(k3);
                if t3 <= t2 || (t3-t2) < tof_min2 || (t3-t2) > tof_max2
                    dv(k1,k2,k3) = NaN;
                else

                    
                    [~,Dv_arr3,V1,~,~,~] = deltavtransfer(t2, t3, planet2, planet3);
                    
                     if Dv_arr3 < window2(1) || Dv_arr3 > window2(2)
                        dv(k1,k2,k3) = NaN;
                     else
                        v8m = V2-v_arr;
                        v8p = V1-v_arr;                                                  
                       [Dvp,~,rp(k1,k2,k3),~,~] = powHyp(v8m,v8p,mu,Rplanet,hatm);   %% Dvp è il dv totale fornito dal gravity assist per iniziare la seconda lambert verso venere 
                        dv(k1,k2,k3) = Dv_dep1 + Dvp + Dv_arr3;                  %%%% dv totale dato da dv per partire da giove+ dv flyby+ dv per frenare a venere
                        Dv_flyby(k1,k2,k3) = Dvp;
                     end
                    end
                 end
                
            end
        end
    end
end

Dv_min = min(min(min(dv)));
 [i,j,k] = ind2sub(size(dv), find(dv == Dv_min));
dep = t_dep(i);
fby = t_flyby(j);
arr = t_arr(k);
y = [t_dep(i),t_flyby(j),t_arr(k)];

if isnan(Dv_min)==false
    fprintf('--> Minimum Dv:\n')
    fprintf('%2.3f',Dv_min)
    fprintf(' km/s.\n')
            fprintf('--> Departure at date ')
            fprintf(string(datetime(mjd20002date(dep))))
            fprintf('\n')
            fprintf('--> Flyby at date ')
            fprintf(string(datetime(mjd20002date(fby))))
            fprintf('\n')
            fprintf('--> Arrival at date ')
            fprintf(string(datetime(mjd20002date(arr))))
            fprintf('\n')
else
    fprintf('Transfer not possible')
end
end