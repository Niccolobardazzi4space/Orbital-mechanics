function [SOL] = alltime_mat (dvtot,DEP,FB,ARR,dv_desired)

%      alltime_mat.m - computes a 3D scatter plot visualizing every point
%      in a matrix 
%     
%     
%     DESCRIPTION:
%            this function takes a 3-dimensional matrix and plots all its
%            values that are lower wrt a constraint 
%     
%     INPUT: 
%          dvtot = 3D matrix of dv, calculated from a triple loop (deltavtransfer)
%         
%          DEP = structure: earliest and latest departure dates, both in
%          dates and mjd2000 format;

%          FB = structure: earliest and latest flyby dates, both in
%          dates and mjd2000 format;

%          ARR = structure: earliest and latest arrival dates, both in
%          dates and mjd2000 format

%          dv_desired = upper boundary, exclude every value bigger than
%          this one.

%     OUTPUT:
%          SOL: structure
%          3D scatter plot

%     CALLED FUNCTIONS:
%                       -----
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%      
addpath(genpath(pwd))

n_it = length(dvtot(:,1,1));
t_dep = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, n_it);
t_flyby = linspace(FB.Earliest_mjd2000, FB.Latest_mjd2000, n_it);
t_arr = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, n_it);

% Interesting solutions
[rows,cols,deeps] = size(dvtot);
a = 1;
for i = 1:rows
    for j = 1:cols
        for k = 1:deeps
            if dvtot(i,j,k)<dv_desired
                    SOL(a).dv = dvtot(i,j,k);
                    SOL(a).dep = mjd20002date(t_dep(i));
                    SOL(a).fb  = mjd20002date(t_flyby(j));
                    SOL(a).arr = mjd20002date(t_arr(k));
                    SOL(a).depmjd = t_dep(i);
                    SOL(a).fbmjd = t_flyby(j);
                    SOL(a).arrmjd = t_arr(k);
                    a = a+1;
                else
                    dvtot(i,j,k) = NaN;
                
            end
        end
    end
end

for k1 = 1:length(t_dep)
    
    dates_tdep(k1) = datetime(mjd20002date(t_dep(k1)));
    dates_tarr(k1) = datetime(mjd20002date(t_arr(k1)));
    dates_tfb(k1) = datetime(mjd20002date(t_flyby(k1)));
    
end

% Display 3d matrix
figure()

[X,Y,Z] = ndgrid(dates_tdep, dates_tfb, dates_tarr);
pointsize = 30;
scatter3(X(:), Y(:), Z(:), pointsize, dvtot(:),'*');
grid minor
xtickformat('yyyy-MMM-dd')
ytickformat('yyyy-MMM-dd')
ztickformat('yyyy-MMM-dd')
xlabel('Departure');
ylabel('Fly-by');
zlabel('Arrival');
c = jet;
c = flipud(c);
colormap(c);
colorbar

                






