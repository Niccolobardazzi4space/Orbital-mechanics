function [launch] = PcPlot(dv,DEP,FB,ARR,planets,rp)
%%
%      PcPlot.m - Points from Porkchop plot organization
%     
%     PROTOTYPE:
%     	launch = PcPlot(dv,DEP,FB,ARR,n_it,planets)
%     
%     DESCRIPTION:
%       This function creates the variable launch and a txt file with the points from
%       the matrix dv that are non NaN. Also organizes them.
%     
%     INPUT:
%       dv[N,N]     NxN matrix with the dv analyzed [km/s]
%       DEP         Structure containing departure max and departure min
%                   times, as specified in the main script.
%       FB         Structure containing flyby max and departure min
%                   times, as specified in the main script.
%       ARR         Structure containing arrival max and departure min
%                   times, as specified in the main script.
%       planets[1,N]    Integer vector with numbers identifying the planets for transfer in 
%                       the order they are visited
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%     
%     OUTPUT:
%       launch[x,6]    Integer number identifying the planets for transfer in 
%                       the order they are visited
%                   1:   integer identificator by departure time
%                   2:   dv value [km/s]
%                   3:   departure time [days]
%                   4:   flyby time [days]
%                   5:   arrival time [days]
%                   6:   ToF [days]
%     
%     CALLED FUNCTIONS:
%       astroConstants.m
%       setup_Helioplot.m
%       kp2rv.m
%       ode_orbit.m
%       DrawPlanetsOrbits
%   
%     LAST UPDATED:
%      02/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.


n_it = length(dv(:,1,1));
t_dep = linspace(DEP.Earliest_mjd2000, DEP.Latest_mjd2000, n_it);
t_flyby = linspace(FB.Earliest_mjd2000, FB.Latest_mjd2000, n_it);
t_arr = linspace(ARR.Earliest_mjd2000, ARR.Latest_mjd2000, n_it);

planet1 = planets(1);
planet2 = planets(2);
planet3 = planets(3);

dv_max = 50; wdw = 0;

for i = 1:length(dv(:,1,1))
    tx(i) = t_dep(i);
    for j = 1:length(dv(1,:,1))
        t1 = t_flyby(j);
        for k = 1:length(dv(1,1,:))
            ToF(i,j,k) = t_arr(k) - tx(i);
            if isnan(dv(i,j,k))==false
                wdw = wdw+1;
                launch(wdw,1) = wdw; launch(wdw,2)=dv(i,j,k); launch(wdw,3) = t_dep(i);
                launch(wdw,4) = t_flyby(j); launch(wdw,5) = t_arr(k); launch(wdw,6) = ToF(i,j,k); launch(wdw,7) = rp(i,j,k);
            end
        end
    end
end

[~, sortOrder] = sort(launch(:,2), 'ascend'); %Change sorting variable here
launch = launch(sortOrder,:);


fileID = fopen('LaunchWindows_best_dv.txt','w'); %Change filename here
fprintf(fileID,'Window |   dv     |    ToF   |   rp   |     Departure        |        Flyby         |       Arrival        |\n');
fprintf(fileID,'\n');
for i = 1:wdw
    fprintf(fileID,'   %3u      %3.3f | %5.2f | %5.3f | ',launch(i,1),launch(i,2),launch(i,6),launch(i,7));
    fprintf(fileID,string(datetime(mjd20002date(launch(i,3)))));
    fprintf(fileID,' | ');
    fprintf(fileID,string(datetime(mjd20002date(launch(i,4)))));
    fprintf(fileID,' | ');
    fprintf(fileID,string(datetime(mjd20002date(launch(i,5)))));
    fprintf(fileID,' |\n');
end

fclose(fileID);

end