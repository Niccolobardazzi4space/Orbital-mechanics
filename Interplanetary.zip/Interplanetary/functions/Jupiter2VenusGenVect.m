function dv = Jupiter2VenusGenVect(x,param)
%%
%      Jupiter2VenusGenVect.m - dv computation for transfer with flyby,
%                               written in vectorial form for use with ga algorithm
%     
%   
%     DESCRIPTION:
%       This function returns the total delta v required for the transfer
%       from the first planet (Jupiter) to the third planet (Venus) with a
%       fly-by at the second planet (Mars). Used in the MAIN script for the
%       optimization algorithms.
%     
%     INPUT:
%       
%       x[1,N]          Time of departure, fly-by and arrival in MJD2000
%       param           Structure containing the following data:
%                       - planet1, planet2, planet3 (same numbers as in
%                       uplanet.m)
%                       - planetary constant and radius of planet2 (where fly-by happens)
%                       - atmosphere altitude (minimum altitude for fly-by)
%                       - limits for delta v, to exclude too high values
%     
%     OUTPUT:
%       dv              Total delta v for the transfer [km/s]
%     
%     CALLED FUNCTIONS:
%      deltavtransfer.m 
%      powHyp.m 
%
%     LAST UPDATED:
%      02/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.


%%

t_dep = x(:,1); t_flyby = x(:,2); t_arr = x(:,3);

planet1 = param.planet1; planet2 = param.planet2; planet3 = param.planet3;
mu = param.mu; Rplanet = param.Rplanet; hatm = param.hatm;
Dv1_max = param.Dv1_max; Dv2_max = param.Dv2_max;
dv = zeros(size(t_dep));

    for j=1:length(x(:,1))
        [Dv_dep1,~,~,V2,~,v_arr] = deltavtransfer(t_dep(j), t_flyby(j), planet1, planet2);
        if Dv_dep1<=Dv1_max
            [~,Dv_arr2,V1,~,~,~] = deltavtransfer(t_flyby(j), t_arr(j), planet2, planet3);
            if Dv_arr2<=Dv2_max
                v8m = V2-v_arr;
                v8p = V1-v_arr;
                [Dvp,delta,rp,hypin,hypout] = powHyp(v8m,v8p,mu,Rplanet,hatm);
                dv(j) = Dv_dep1+Dv_arr2+Dvp;
            else
                dv(j) = NaN;
                
            end
        else
            dv(j) = NaN;
            
        end
    end

end


