function [delta_v_tot, delta_v_1, delta_v_2] = deltavtransfer1(t_dep, t_arr, planet1, planet2,window)

% Function to compute the total deltav for an interplanetary transfer
% given departure and arrival dates t_dep and t_arr.
%
% This function calls 'date2mjd2000.m' to convert t_dep and t_arr from 
% Gregorian calendar to MJD2000.
% Date in the Gregorian calendar must be entered as a 6-element vector:
%               [year, month, day, hour, minute, second]
%
% Position of planet 1 and 2 at t_dep and t_arr are calculated in keplerian param.
% using 'uplanet.m' (ephemerides).
% Planet of departure and arrival must be specified entering:
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%                   10:  Sun
%
%     CALLED FUNCTIONS:
%            uplanet.m
%            kp2rv.m
%            lambertMR.m
%
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

% Date conversion

dep_mjd = date2mjd2000(t_dep);
arr_mjd = date2mjd2000(t_arr);

% Computation of time of flight

tof = (arr_mjd - dep_mjd)*24*60^2;

% Position of planet 1 and 2 

[kep_dep,ksun_dep] = uplanet(dep_mjd, planet1);
[kep_arr,ksun_arr] = uplanet(arr_mjd, planet2);

% Conversion to (r,v)

[r_dep,v_dep]=kp2rv(kep_dep(1),kep_dep(2),kep_dep(3),kep_dep(4),kep_dep(5),kep_dep(6),ksun_dep);
[r_arr,v_arr]=kp2rv(kep_arr(1),kep_arr(2),kep_arr(3),kep_arr(4),kep_arr(5),kep_arr(6),ksun_arr);

% Lambert solver for the transfer

muS = astroConstants(4);
[~,~,~,~,V1,V2,~,~] = lambertMR(r_dep,r_arr,tof,muS,0,0,0,1);
V1 = V1';
V2 = V2';

% Deltav
delta_v_1 = norm(V1 - v_dep);
delta_v_2 = norm(v_arr - V2);
delta_v_tot = delta_v_1 + delta_v_2;
  if tof > 0 
      if delta_v_1 < window(2) && delta_v_2 < window(2) && delta_v_1 > window(1) && delta_v_2 > window(1) && delta_v_tot < window(2) && delta_v_tot > window(1)
          delta_v_1 = norm(V1 - v_dep);
          delta_v_2 = norm(v_arr - V2);
          delta_v_tot = delta_v_1 + delta_v_2;
      else
          delta_v_1 = NaN;
          delta_v_2 = NaN;
          delta_v_tot = NaN;
      end
  else
      delta_v_1 = NaN;
      delta_v_2 = NaN;  
      delta_v_tot = NaN;
  end
end


