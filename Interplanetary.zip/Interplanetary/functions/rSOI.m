function r_SOI = rSOI(R, planet)
%%
%     rSOI.m 
%     
%     
%     DESCRIPTION:
%       This function computes the radius of the sphere of influence (SOI)
%       of a planet
%     
%     INPUT:
%       R = distance of the planet from the Sun [km]
%       planet = id number of the planet
%        Planets are numbered as follows:
%           1  Me      
%           2  V       
%           3  E       
%           4  Ma      
%           5  J       
%           6  S       
%           7  U       
%           8  N       
%           9  P       
%           0  Moon    
%     
%     OUTPUT:
%       r_SOI = radius of the SOI [km]
%      
%    
%     CALLED FUNCTIONS:
%      astroConstants.m
%       
%     LAST UPDATED:
%      10/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%

% Mass of the planet
m_p = astroConstants(10+planet)/astroConstants(1);

% Mass of the Sun
m_s = astroConstants(4)/astroConstants(1);

% Radius of the sphere of influence
r_SOI = R*(m_p/m_s)^(2/5);
