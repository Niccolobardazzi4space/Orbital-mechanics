function [delta_t_in,delta_t_out,dt] = FlybyTimes(planets,hatm,times)
%%
%     FlybyTimes.m 
%     
%     
%     DESCRIPTION:
%       This function computes the time spent inside a planet's SOI for a
%       powered fly-by
%     
%     INPUT:
%       
%       times = vector containing the dates of departure, fly-by and
%               arrival [MJD2000 days]  
%       hatm = minimum fly-by altitude [km]
%       planets = vector structured as: [planet1; planet2; planet3]; 
%        Planets are numbered as follows:
%           1  Me      
%           2  V       
%           3  E       
%           4  Ma      
%           5  J       
%           6  S       
%           7  U       
%           8  N       
%           9  P       
%           0  Moon    
%     
%     OUTPUT:
%       delta_t_in = time spent on incoming arc [sec]
%       delta_t_out = time spent on out-coming arc [sec]
%       dt = total time spent inside SOI [sec]
%    
%     CALLED FUNCTIONS:
%       astroConstants.m
%       deltavtransfer.m
%       powHyp.m
%       uplanet.m
%       rSOI.m
%       delta_t_hyp.m
%       
%     LAST UPDATED:
%      10/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%

planet1 = planets(1);
planet2 = planets(2);
planet3 = planets(3);

mu = astroConstants(10 + planet2);
Rplanet = astroConstants(20+planet2);

t_dep = times(1);
t_flyby = times(2);
t_arr = times(3);

[~,~,~,V2,~,v_arr] = deltavtransfer(t_dep, t_flyby, planet1, planet2);
[~,~,V1,~,~,~] = deltavtransfer(t_flyby, t_arr, planet2, planet3);
v8m = V2-v_arr;
v8p = V1-v_arr;                                                  
[~,~,~,hypin,hypout] = powHyp(v8m,v8p,mu,Rplanet,hatm);

[kep,~] = uplanet(t_flyby, planet2);
[R,~] = kp2rv(kep(1), kep(2), kep(3), kep(4), kep(5), kep(6), astroConstants(4));
R = norm(R);
r_SOI = rSOI(R, planet2);

f_in = @(theta) r_SOI - hypin.h^2/mu*(1+hypin.e*cos(theta))^(-1);
f_out = @(theta) r_SOI - hypout.h^2/mu*(1+hypout.e*cos(theta))^(-1);

options = optimoptions('fsolve','Display','off','FunctionTolerance',1e-16);
theta_in = fsolve(@(theta) f_in(theta),pi/2,options);
theta_out = fsolve(@(theta) f_out(theta),pi/2,options);

delta_t_in = delta_t_hyp(hypin.e, hypin.h, -theta_in, 0, planet2);
delta_t_out = delta_t_hyp(hypout.e, hypout.h, 0, theta_out, planet2);
dt = delta_t_in + delta_t_out; % seconds
end