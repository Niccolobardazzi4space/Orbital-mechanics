function Helioplot(planets,times)
%%
%      Helioplot.m - Heliocentric transfer plot
%     
%     PROTOTYPE:
%     	Helioplot(planets,times)
%     
%     DESCRIPTION:
%       This function plots on a preexisting figure the heliocentric transfer between N planets.
%     
%     INPUT:
%       planets[1,N]    Integer number identifying the planets for transfer in 
%                       the order they are visited
%                   1:   Mercury
%                   2:   Venus
%                   3:   Earth
%                   4:   Mars
%                   5:   Jupiter
%                   6:   Saturn
%                   7:   Uranus
%                   8:   Neptune
%                   9:   Pluto
%       times[1,N]      Times for reaching and departing from planets, ordered
%                       chronologically in MJD2000 [days]
%     
%     OUTPUT:
%       plot
%     
%     CALLED FUNCTIONS:
%       astroConstants.m
%       setup_Helioplot.m
%       kp2rv.m
%       ode_orbit.m
%       DrawPlanetsOrbits
%
%     LAST UPDATED:
%      02/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D. 


%% Constants
AU = astroConstants(2); muS = astroConstants(4); t0 = times(1); tol = 1e2;
%% Celestial central body
% plot_planet(astroConstants(3)/AU)
% hold on
setup_Helioplot;
legtext = ['Sun'];
V1_pre = [0;0;0];
fprintf('Running Helioplot, this is your request:\n')
%% Integration
for i=1:length(times)-1
    t_start = (times(i)-t0)*3600*24; t_end = (times(i+1)-t0)*3600*24;                   % Beginning of each manoeuvre
    [kep0,~] = uplanet(times(i),planets(i));                                            % Keplerian coordinates of departure planet
    [~,~,V0,V1,~,~] = deltavtransfer(times(i), times(i+1), planets(i), planets(i+1));    % Calculate transfer from first to second planet
    [kep1,~] = uplanet(times(i+1),planets(i+1));                                        % Keplerian coordinates of departure planet
    [R0,VPlanet0]=kp2rv(kep0(1),kep0(2),kep0(3),kep0(4),kep0(5),kep0(6),muS);
    [R1,VPlanet1]=kp2rv(kep1(1),kep1(2),kep1(3),kep1(4),kep1(5),kep1(6),muS);
    
    if i==1
        Dv_dep = norm(V0-VPlanet0);                                                     % Dv at departure from first planet
        fprintf('--> Departure from planet ')
        fprintf(string(planets(i)))
        fprintf(' at date ')
        fprintf(string(datetime(mjd20002date(times(i)))))
        fprintf('\n')
    end
    
    if i~= 1
        v8m = V1_pre-VPlanet0;
        v8p = V0 - VPlanet0;
        [Dv_flyby(i-1),~,~,~,~] = powHyp(v8m,v8p,astroConstants(10+planets(i)),astroConstants(20+planets(i)),50); % Dv at flyby perigee
        fprintf('--> Flyby at planet ')
        fprintf(string(planets(i)))
        fprintf(' at date ')
        fprintf(string(datetime(mjd20002date(times(i)))))
        fprintf('\n')
    end
    
    if i==length(times)-1
        Dv_arr = norm(VPlanet1-V1);                                                     % Dv at arrival to last planet
        fprintf('--> Arrival at planet ')
        fprintf(string(planets(i+1)))
        fprintf(' at date ')
        fprintf(string(datetime(mjd20002date(times(i+1)))))
        fprintf('\n')
    end
    
    Y0 = [R0,V0]; tspan = [0,t_end-t_start];
    options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10); % Integration options
    [~,Y] = ode113(@(t,Y) ode_orbit(t,Y,muS),tspan,Y0,options);
    R = Y(:,1:3)';
    plot_orbit(R'/AU)
    legtext = [legtext,strcat('Transfer ',string(i))];
    hold on

    %Disclaimer in case something is not correct
    if norm(R(1:3,end)-R1)>tol
        fprintf('The trajectory is not arriving to the planet in iteration')
        fprintf(string(i))
        fprintf(strcat(' from planet ',string(planets(i)),' to planet ',string(planets(i+1))),'\n')
    end
    V1_pre = V1;
end
legend(legtext)
Dv_tot = Dv_dep+Dv_arr+sum(Dv_flyby);
fprintf('CHECK\n')
if isnan(Dv_tot)==false
    fprintf(strcat('--> For this manoeuvre the total flyby is Dv= ',string(Dv_tot),' km/s.\n'))
else
    fprintf(strcat('--> This transfer is unrealistic.\n'))
end
DrawPlanetsOrbits(planets,times)
end