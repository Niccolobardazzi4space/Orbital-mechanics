function flyby = flyby_charact(x,param)
%%
%      flyby_charact.m - fly-by characterization
%     
%     
%     DESCRIPTION:
%       This function saves in a structure the relevant parameters of the fly-by.
%     
%     INPUT:
%       
%       x[1,N]          Time of departure, fly-by and arrival in MJD2000
%       param           Structure containing the following data:
%                       - planet1, planet2, planet3 (same numbers as in
%                       uplanet.m)
%                       - planetary constant and radius of planet2 (where fly-by happens)
%                       - atmosphere altitude (minimum altitude for fly-by)
%     
%     OUTPUT:
%       structure
%     
%     CALLED FUNCTIONS:
%      deltavtransfer.m 
%      powHyp.m 
%      FlybyTimes.m 
%
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%      
%
%%

t_dep = x(1); t_flyby = x(2); t_arr = x(3);
planet1 = param.planet1; planet2 = param.planet2; planet3 = param.planet3;
mu = param.mu; Rplanet = param.Rplanet; hatm = param.hatm;

[Dv_dep1,~,~,V2,~,v_arr] = deltavtransfer(t_dep, t_flyby, planet1, planet2);
[~,Dv_arr2,V1,~,~,~] = deltavtransfer(t_flyby, t_arr, planet2, planet3);
v8m = V2-v_arr;
v8p = V1-v_arr;
[Dvp,delta,rp,hypin,hypout] = powHyp(v8m,v8p,mu,Rplanet,hatm);

[~,~,dt] = FlybyTimes([planet1; planet2; planet3],hatm,x);

flyby.dv_ga = Dvp;
flyby.dv_flyby = norm(V1-V2);
flyby.rp = rp;
flyby.impact1 = hypin.D;
flyby.impact2 = hypout.D;  
flyby.fbaltitude = rp - Rplanet;
flyby.turnangle = delta;
flyby.dv_dep = Dv_dep1;
flyby.dv_arr = Dv_arr2;
flyby.timeinSOI = dt/3600; % hours

disp(' ')
fprintf('The fly-by manoeuvre which provides the minimum Δv has the following characteristics:');
disp(' ')
fprintf('Δv required at departure [km/s]: %f\n',flyby.dv_dep);
fprintf('Total Δv of the fly-by [km/s]: %f\n',flyby.dv_flyby);
fprintf('Δv required for powered fly-by [km/s]: %f\n',flyby.dv_ga);
fprintf('Δv required at arrival [km/s]: %f\n',flyby.dv_arr);
fprintf('Impact parameter for fly-by [km]: %f\n',flyby.impact1);
fprintf('Fly-by altitude [km]: %f\n',flyby.fbaltitude);
fprintf('Time spent inside SOI [hours]: %f\n',flyby.timeinSOI);

end