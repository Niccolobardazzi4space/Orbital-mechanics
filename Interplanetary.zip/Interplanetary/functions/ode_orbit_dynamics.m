function [dy] = ode_orbit_dynamics(~,y,mu)
%%
%      ode_orbit_dynamics.m -- function used for numerical integration with ode
%     
%     INPUT: 
%          y = vector of states [rx; ry; rz; vx; vy; vz]
%          mu = planetary constant [km^3/s^2]
%     
%     OUTPUT:
%          dy
%     CALLED FUNCTIONS:
%                       -----
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
rx = y(1);
ry = y(2);
rz = y(3);
vx = y(4);
vy = y(5);
vz = y(6);
r  = sqrt(rx.^2+ry.^2+rz.^2);
dy(1,1) = vx;           %velocità     dy vettore degli stati finale (velocità e accelerazione)
dy(2,1) = vy;
dy(3,1) = vz;
dy(4,1) = -mu*rx/r.^3;  %accelerazioni
dy(5,1) = -mu*ry/r.^3;
dy(6,1) = -mu*rz/r.^3;
end

%function dq = ode_orbit_dynamics(~, q, mu)

%x = q(1);
%y = q(2);
%z = q(3);

%r = sqrt(x^2 + y^2 + z^2);

%dq = [zeros(3,3) eye(3)
 %   -mu/r^3*eye(3) zeros(3,3)]*q;

%end