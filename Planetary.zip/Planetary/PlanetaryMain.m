%% Planetary mission assignment of Group 9
%
%     LAST UPDATED:
%      21/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%      As well as for the functions used in the script, which are all
%      loaded in folder /functions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                   PART 1 - GROUND TRACKS AND RGT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clearvars; clc;
addpath(genpath(pwd))
%% Parameters

Re = astroConstants(23) ;
J2 = 0.00108263 ;
mu = astroConstants(13) ; 

%% Initial condition

e = 0.2991; a = 3.3923e4; i = 23.4859*pi()/180; O = 0*pi()/180; o = 0*pi()/180; theta = 0 ;
truLon = theta+o+O; argLat = o+theta ; lonPer = O+o; p = a*(1-e^2) ;
green_lon0 = 0 ;
[r0,v0] = orb2rv(p,e,i,O,o,theta,truLon,argLat,lonPer,mu) ;

%% Time span for integration
T_year = 365.25*24*60*60 ; % 1 year time, in seconds
T_day = 23*3600+56*60+4.0916; % 1 sidereal day time
T = 2*pi*sqrt(a^3/mu) ; % Orbit period
n_periods = 10 ;
t_start = 0 ;
t_end = 10*T_day ;
tspan=[t_start,t_end] ; % Time span for integration

%% Options and non-perturbated equation solving
y0 = [r0,v0] ; % Initial conditions
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10) ;
[t,y] = ode113(@(t,y) ode_orbit(t,y,mu),tspan,y0,options) ;
r = y(:,1:3) ;
v = y(:,4:6) ;

[tJ2,yJ2] = ode113(@(tJ2,yJ2) ode_orbit_perturb(tJ2,yJ2,mu,J2,Re),tspan,y0,options) ;
rJ2 = yJ2(:,1:3) ;
vJ2 = yJ2(:,4:6) ;

%% Plotting
fignum=1; %Start figure counting

%Static orbit plot
figure(fignum); fig_OrbitPlot = fignum;
plot_orbit(r);
title('Orbit Plot')
hold on
create_Earth;
axis equal
grid minor
fignum = fignum+1;

%Ground Track plot 1 orbit
figure(fignum); fig_GTP_1O = fignum;
iend = find(t>T,1);
[~,~,lat,lon]=GroundTrack(r(1:iend,:),green_lon0,t(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,t(1:iend));
GroundTrackPlot(lat_corrected,lon_corrected);
title('1 PERIOD')
fignum = fignum+1;

hold on
iend = find(tJ2>T,1);
[~,~,lat,lon]=GroundTrack(rJ2(1:iend,:),green_lon0,tJ2(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tJ2(1:iend));
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('Unperturbated','Start 1','End 1','J2 perturbation','Start 2','End 2')

%Ground Track plot 1 day
figure(fignum); fig_GTP_1D = fignum;
iend = find(t>T_day,1);
[~,~,lat,lon]=GroundTrack(r(1:iend,:),green_lon0,t(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,t(1:iend));
GroundTrackPlot(lat_corrected,lon_corrected);
title('1 DAY')
fignum = fignum+1;

hold on
iend = find(tJ2>T_day,1);
[~,~,lat,lon]=GroundTrack(rJ2(1:iend,:),green_lon0,tJ2(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tJ2(1:iend));
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('Unperturbated','Start 1','End 1','J2 perturbation','Start 2','End 2')

%Ground Track plot 10 day
figure(fignum); fig_GTP_10D = fignum;
[~,~,lat,lon]=GroundTrack(r,green_lon0,t);
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,t);
GroundTrackPlot(lat_corrected,lon_corrected);
title('10 DAYs'); h2 = findobj('Type', 'line'); set(h2,'LineWidth',3);
fignum = fignum+1;

hold on
[~,~,lat,lon]=GroundTrack(rJ2,green_lon0,tJ2);
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tJ2);
plot(lon_corrected,lat_corrected,'--g','LineWidth',3);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('Unperturbated','Start 1','End 1','J2 perturbation','Start 2','End 2')

%% Calculation of RGT with J2 corrections
clear r0 v0 y0;

a0 = a;
% a0 = 26600; e = 0.74; i = 63.4*pi/180; O = 50*pi/180; o = 280*pi/180; theta = 0;
% truLon = theta+o+O; argLat = o+theta ; lonPer = O+o;

a1 = RGT(7,5,mu); p = a1*(1-e^2); green_lon0 = 0;
[r0,v0] = orb2rv(p,e,i,O,o,theta,truLon,argLat,lonPer,mu);

aJ2 = RGTJ2(7,5,mu,a1,J2,Re,e,i); p = aJ2*(1-e^2);
[r0J2,v0J2] = orb2rv(p,e,i,O,o,theta,truLon,argLat,lonPer,mu);

%% Options and perturbated equation solving
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10);
y0 = [r0,v0]; %Initial conditions
% [tRGT,yRGT] = ode113(@(tRGT,yRGT) ode_orbit(tRGT,yRGT,mu),tspan,y0,options);
[tRGT,yRGT] = ode113(@(tRGT,yRGT) ode_orbit_perturb(tRGT,yRGT,mu, J2, Re),tspan,y0,options);
rRGT = yRGT(:,1:3);
vRGT = yRGT(:,4:6);

y0J2 = [r0J2,v0J2]; %Initial conditions
[tRGTJ2,yRGTJ2] = ode113(@(tRGTJ2,yRGTJ2) ode_orbit_perturb(tRGTJ2,yRGTJ2,mu, J2, Re),tspan,y0J2,options);
rRGTJ2 = yRGTJ2(:,1:3);
vRGTJ2 = yRGTJ2(:,4:6);

%% Plots

% 1 PERIOD
 
figure(fignum);
iend = find(tRGT>T,1);
[~,~,lat,lon]=GroundTrack(rRGT(1:iend,:),green_lon0,tRGT(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tRGT(1:iend));
GroundTrackPlot(lat_corrected,lon_corrected);
title('1 PERIOD RGT')
fignum = fignum+1;

hold on
iend = find(tRGTJ2>T,1);
[~,~,lat,lon]=GroundTrack(rRGTJ2(1:iend,:),green_lon0,tRGTJ2(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tRGTJ2(1:iend));
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('RGT Unperturbated','Start 1','End 1','RGT J2 perturbation','Start 2','End 2')

% 1 DAY
figure(fignum);
iend = find(tRGT>T_day,1);
[~,~,lat,lon]=GroundTrack(rRGT(1:iend,:),green_lon0,tRGT(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tRGT(1:iend));
GroundTrackPlot(lat_corrected,lon_corrected);
title('1 DAY RGT')
fignum = fignum+1;

hold on
iend = find(tRGTJ2>T_day,1);
[~,~,lat,lon]=GroundTrack(rRGTJ2(1:iend,:),green_lon0,tRGTJ2(1:iend));
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tRGTJ2(1:iend));
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('RGT Unperturbated','Start 1','End 1','RGT J2 perturbation','Start 2','End 2')

% 10 DAY
figure(fignum);
[~,~,lat,lon]=GroundTrack(rRGT,green_lon0,tRGT);
[lon_corrected,lat_corrected,~] = correct_lon(lon,lat,tRGT);
GroundTrackPlot(lat_corrected,lon_corrected); lat_correctedJ2 = lat_corrected; lon_correctedJ2 = lon_corrected;
title('10 DAY RGT'); h2 = findobj('Type', 'line'); set(h2,'LineWidth',3);
fignum = fignum+1;

hold on
[~,~,lat,lon]=GroundTrack(rRGTJ2,green_lon0,tRGTJ2);
[lon_corrected,lat_corrected,t_corrected] = correct_lon(lon,lat,tRGTJ2);
plot(lon_corrected,lat_corrected,'--g','LineWidth',3);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
legend('RGT Unperturbated','Start 1','End 1','RGT J2 perturbation','Start 2','End 2')

% Plot Zoom for axis
axes('Position',[.2 .2 .2 .2])
box on
GroundTrackPlot(lat_correctedJ2,lon_correctedJ2); h2 = findobj('Type', 'line'); set(h2,'LineWidth',1.5);
hold on
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
xlim([-2,2]); ylim([-1.5,1.5]);
% Second zoom
axes('Position',[.7 .2 .2 .2])
box on
GroundTrackPlot(lat_correctedJ2,lon_correctedJ2); h2 = findobj('Type', 'line'); set(h2,'LineWidth',1.5);
hold on
plot(lon_corrected,lat_corrected,'--g','LineWidth',1.5);
drawStartEnd([lon_corrected(1),lat_corrected(1)],[lon_corrected(end),lat_corrected(end)],'g');
xlim([8,10]); ylim([5,7]);
%% Perturbed orbit over 10 years for plot
t_start = 0;
t_end = 10*T_year;
tspan=[t_start,t_end]; %Time span for integration
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10);
[~,y_p] = ode113(@(tRGT,yRGT) ode_orbit_perturb(tRGT,yRGT,mu, J2, Re),tspan,y0J2,options);
r_vect_p = y_p(:,1:3);
col = linspace(0,10*T_year,length(r_vect_p));

%% Plot 10 YEARS

figure(fignum)
title('Perturbed orbit (J2)')
earth = plot_earth();
surface([r_vect_p(:,1)';r_vect_p(:,1)'],[r_vect_p(:,2)';r_vect_p(:,2)'],[r_vect_p(:,3)';r_vect_p(:,3)'],[col;col],'facecol','no','edgecol','interp')
axis equal
view(70,0)
set(gca, 'Color', 'k');
colorbar('Ticks',[0,2*T_year, 4*T_year, 6*T_year, 8*T_year, 10*T_year],'TickLabels',{'0','2 years','4 years','6 years','8 years','10 years'});
grid on
ax = gca;
ax.GridColor = 'w';
hold on
fignum = fignum+1;

% %% Animated orbit plot
% % Warning prompt
% prompt = '\n The orbit video will be displayed now.\n It may take a while. Continue? Y/N [N]: ';
% str = input(prompt,'s');
% if isempty(str)
%     str = 'N';
% end
% if str== 'Y' || str== 'y'
%     figure(fignum)
%     fh = findobj( 'Type', 'Figure','Number',fig_OrbitPlot) ;
%     xLimits = fh.CurrentAxes.XLim;  %# Get the range of the x axis
%     yLimits = fh.CurrentAxes.YLim;  %# Get the range of the y axis
%     zLimits = fh.CurrentAxes.ZLim;  %# Get the range of the z axis
%     axis3d = [xLimits;yLimits;zLimits];
%     animated_orbit(r,2e2,axis3d,t,green_lon0)
%     fignum = fignum+1 ;
% end
% %% Animated GTP
% % Warning prompt
% prompt = '\n The ground track plot video will be displayed now.\n It may take a while. Continue? Y/N [N]: ';
% str = input(prompt,'s');
% if isempty(str)
%     str = 'N';
% end
% if str== 'Y' || str== 'y'
%     figure(fignum)
%     animated_GTP(lat_corrected,lon_corrected,2e3,t_corrected)
%     fignum = fignum+1 ;
% end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                   PART 2 - MOON PERTURBATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clearvars -except fignum;
clc;
addpath(genpath(pwd))
fig = fignum+10;
%% Parameters

Re = astroConstants(23); %Earth radius
J2 = 0.00108263; %J2 perturbating factor
mu = astroConstants(13); % for earth
muM = astroConstants(20);
MJD0 = date2mjd2000([2000, 12, 29, 0, 0, 0]);

%% Initial condition

e = 0.2991; a = 3.3923e4; i = 23.4859*pi()/180; O = 0*pi()/180; o = 0*pi()/180; theta = 0;
[r0,v0] = kp2rv(a,e,i,O,o,theta,mu);
q0 = [r0,v0];
g0 = [a,e,i,O,o,theta]';

%% Time span for integration
T_year = 365.25*24*60*60; %1 year time, in seconds
T_day = 24*3600; %1 day time, in seconds
T = 2*pi*sqrt(a^3/mu); %Orbit period
t_start = 0;
t_end = 6*10*T_day;
% t_end = 60*T_day;
tspan=[t_start,t_end]; %Time span for integration

%% Options and orbit propagation with Gauss
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10);
tic
[t_gauss,g] = ode113(@(t_gauss,g) GaussJ2Moon(t_gauss, g, mu, J2, Re, muM, MJD0), tspan, g0, options);
odegauss_elapsedTime = toc;

% Filtering for Gauss

incl = zeros(1,length(g)); Raan = zeros(1,length(g)); aop = zeros(1,length(g)); ta = zeros(1,length(g));
for i = 1:length(g)
    incl(i) = rad2deg(g(i,3));
    Raan(i) = rad2deg(g(i,4));
    aop(i) = rad2deg(g(i,5));
    ta(i) = rad2deg(g(i,6));
end
t_gauss = t_gauss/24/3600;
figure(fig)
orb = g;  orbGauss = orb;
T = T/24/3600;
[elements,orb_filt] = movfilter(orb,t_gauss,1000,T);
[fig,fighandle] = paramplots(t_gauss,elements,fig);
overfiltplots(orb_filt,fighandle)

%% Orbit propagation in r,v
% For Moon and J2 perturbation
tic
[t_rv,q] = ode113(@(t_rv,q) ode_orbit_J2Moon(t_rv, q, mu, J2, Re, muM, MJD0), tspan, q0, options);
oderv_elapsedTime = toc;
r = q(:,1:3);
v = q(:,4:6);
% Only J2 perturbation
[t_onlyJ2,q_onlyJ2] = ode113(@(t_rv,q) ode_orbit_perturb(t_rv, q, mu, J2, Re), tspan, q0, options);
r_onlyJ2 = q_onlyJ2(:,1:3);
v_onlyJ2 = q_onlyJ2(:,4:6);

%% Filtering
% Moon & J2
orb = zeros(length(r),1);
for i = 1:length(r)
    [orb(i,1),orb(i,2),orb(i,3),orb(i,4),orb(i,5),orb(i,6),~,~,~,~] = rv2orb(r(i,:)',v(i,:)',mu);
end 

t_rv = t_rv/24/3600;
figure(fig)
n = 1000; 
orbRV = orb;
[orb,prog_filt] = movfilter(orb,t_rv,n,T);
[fig,fighandle] = paramplots(t_rv,orb,fig);
sgtitle('Orbital states')
overfiltplots(prog_filt,fighandle)

% J2 only
orb = zeros(length(r_onlyJ2),1);
for i = 1:length(r_onlyJ2)
    [orb(i,1),orb(i,2),orb(i,3),orb(i,4),orb(i,5),orb(i,6),~,~,~,~] = rv2orb(r_onlyJ2(i,:)',v_onlyJ2(i,:)',mu);
end 
orbRV_onlyJ2 = orb;

t_onlyJ2 = t_onlyJ2/24/3600; n = 1000; 
[~,prog_filt] = movfilter(orb,t_onlyJ2,n,T);
figure(fighandle);
for i=1:6
    h=subplot(3,2,i);
    hold on
    plot(prog_filt(:,1),prog_filt(:,i+1),'r');
%    legend('Output','Filtered','Only J2 filtered');
end
%% Comparison of the two methods

% Interpolation

x = linspace(t_start,t_end/24/3600,1000);

a_interp_g = interp1(t_gauss,orbGauss(:,1),x);
ecc_interp_g = interp1(t_gauss,orbGauss(:,2),x);
incl_interp_g = interp1(t_gauss,orbGauss(:,3),x);
RAAN_interp_g = interp1(t_gauss,orbGauss(:,4),x);  RAAN_interp_g = wrapTo2Pi(RAAN_interp_g);
AoP_interp_g = interp1(t_gauss,orbGauss(:,5),x);
TA_interp_g = interp1(t_gauss,orbGauss(:,6),x); 

g_interp = [a_interp_g', ecc_interp_g', incl_interp_g', RAAN_interp_g', AoP_interp_g', TA_interp_g'];

a_interp_rv = interp1(t_rv,orbRV(:,1),x);
ecc_interp_rv = interp1(t_rv,orbRV(:,2),x);
incl_interp_rv = interp1(t_rv,orbRV(:,3),x);
RAAN_interp_rv = interp1(t_rv,orbRV(:,4),x);  RAAN_interp_rv = wrapTo2Pi(RAAN_interp_rv);
AoP_interp_rv = interp1(t_rv,orbRV(:,5),x);
TA_interp_rv = interp1(t_rv,orbRV(:,6),x);

rv_interp = [a_interp_rv', ecc_interp_rv', incl_interp_rv', RAAN_interp_rv', AoP_interp_rv', TA_interp_rv'];
%%
figure(fig)
[fig,fighandle] = paramplots_comparison(x,abs(g_interp-rv_interp),fig);
%% CHINASAT7
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                   PART 3 - CHINASAT7 COMPARISON
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Propagation CHINASAT7 initial conditions

e = 0.3098243; a = 4.0464739e+4; i = 27.9436*pi()/180;
O = 28.8262*pi()/180; o = 271.8554*pi()/180; theta = 0;

truLon = theta+o+O; argLat = o+theta; lonPer = O+o; p = a*(1-e^2);
green_lon0 = 0;
[r0,v0] = orb2rv(p,e,i,O,o,theta,truLon,argLat,lonPer,mu);

T_year = 365.25*24*60*60; %1 year time, in seconds
T = 2*pi*sqrt(a^3/mu);    %Orbit period
t_start = 0;
t_end = 10*T_year;
tspan=[t_start,t_end];    %Time span for integration
MJD0 = date2mjd2000([2010, 12, 31, 0, 0, 0]);

%% Options and perturbated equation solving by Kepler equation
y0 = [r0,v0]; 
options = odeset('RelTol',1e-10 , 'AbsTol', 1e-10);
[t,B] = ode113(@(t,y) ode_orbit_J2Moon(t, y, mu, J2, Re,muM,MJD0),tspan,y0,options);
r = B(:,1:3);
v = B(:,4:6);
col = linspace(0,10*T_year,length(r));

%% Filtering
a = zeros(length(r),1);
e = zeros(length(r),1);
incl= zeros(length(r),1);
O = zeros(length(r),1);
o = zeros(length(r),1);
nu = zeros(length(r),1);
for i = 1:length(r)
    [a(i),e(i),incl(i),O(i),o(i),nu(i),~,~,~,~] = rv2orb(r(i,:)',v(i,:)',mu);
end

orb = [a,e,incl,O,o,nu];

t = t/24/3600;
fig = fig+1;
figure(fig)
n = 1000; 
T = T/24/3600;
[orb,prog_filt] = movfilter(orb,t,n,10*T);
[fig,fighandle] = paramplots(t,orb,fig);
sgtitle('Orbital states propagation of CHINASAT7');
overfiltplots(prog_filt,fighandle)


%% TLE data
[dateV,orbital] = readTLE(mu);
dateV = dateV-dateV(1);
orbital = orbital(:,[5 3 1 2 4 6]);
figure(fig);
[orbital,CHINA_filt] = movfilterchina(orbital,dateV,n);
[fig,fighandle] = paramplots(dateV,orbital,fig);
sgtitle('CHINASAT7 measurements');
overfiltplots(CHINA_filt,fighandle);

%% GMAT
times = tspan/24/3600;
[GMAT_filt,fig] = ReadGMAT(fig,times);
sgtitle('GMAT orbital states') 

%% Comparison GMAT and CHINASAT7
prog2CHINA = comparison(prog_filt,CHINA_filt);
GMAT2CHINA = comparison(GMAT_filt,CHINA_filt);

%% Filtered results graph

figure(fig)
t = linspace(times(1),times(2),n);
prog_filt = prog_filt(:,2:end);
CHINA_filt = CHINA_filt(:,2:end);
GMAT_filt = GMAT_filt(:,2:end);
sgtitle('Comparison');
[fig,fighandle] = paramplotsall(t,prog_filt,CHINA_filt,GMAT_filt,fig);