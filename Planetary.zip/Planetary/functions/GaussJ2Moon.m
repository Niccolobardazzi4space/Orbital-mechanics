function dy = GaussJ2Moon(t, y, mu, J2, Re, muM, MJD0)
%
%      GaussJ2Moon.m - Gauss planetary equations with Moon and J2
%     
%     DESCRIPTION:
%       This function calculates the derivative of orbital elements of
%       the SC with time considering J2 perturbation and Moon as third body.
%       Use for integration.
%     
%     INPUT:
%       t [1]   Time
%       y [1,6] [a,e,i,O,o,nu] orbital elements of orbit
%       mu[1]   Planet constant [km3/s2]
%       J2[1]   Planet oblateness parameter.
%       Re[1]   Planet mean radius [km]
%       muM [1] Moon mass parameter [km3/s2]
%       MJD0 [1]Date equivalent to time zero in MJD2000 [days]
%     
%     OUTPUT:
%       dy[]    d[a,e,i,O,o,nu]dt Vector with derivative of orbital 
%               elements of the SC [km/2,1/s,rad/s,rad/s,rad/s,rad/s].
%     
%     CALLED FUNCTIONS:
%       ephMoon
%       orb2rv
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       

    %Inputs and their order
    a = y(1);e = y(2); i = y(3); O = y(4); o = y(5); nu = y(6);
    truLon = nu+o+O; argLat = o+nu; lonPer = O+o;
    p = a*(1-e^2);
    
    [r,v] = orb2rv(p,e,i,O,o,nu,truLon,argLat,lonPer,mu);
    h_angular = norm(cross(r,v));
    
    % Relative reference system setup
    t_vector = v/norm(v); b_vector = cross(r,v)/norm(cross(r,v)); 
    n_vector = cross(b_vector,t_vector);
    
    A = [t_vector(1),t_vector(2),t_vector(3);...
        n_vector(1),n_vector(2),n_vector(3);...
        b_vector(1),b_vector(2),b_vector(3)]; % [t;n;b] = A*[x;y;z]
    
    %Calculate J2 acceleration
    a_vector_x = (r(1)/norm(r))*(5*r(3)^2/norm(r)^2-1);
    a_vector_y = (r(2)/norm(r))*(5*r(3)^2/norm(r)^2-1);
    a_vector_z = (r(3)/norm(r))*(5*r(3)^2/norm(r)^2-3);
    aJ2 = [a_vector_x;a_vector_y;a_vector_z];
    aJ2 = aJ2*((3/2)*(J2*mu*Re^2)/norm(r)^4);      % J2 acceleration inertial [km/s2]
    aJ2 = A*aJ2;
    
    %Compute moon perturbation in ECEF
    tdays = t/24/3600;
    MJD2000 = MJD0+tdays;
    [rM, ~] = ephMoon(MJD2000); rM = rM';
    aM = muM/norm(rM)^3*(-r+3*(dot(rM,r)/norm(rM)^2)*rM);
    aM = A*aM;

    % Sum up all the accelerations in tnb frame
    acc = aJ2+aM;
   
    
    % Gauss planetary equations
    da = 2*a^2*norm(v)/mu*acc(1);
    de = (1/norm(v))*(2*(e+cos(nu))*acc(1) - norm(r)/a*sin(nu)*acc(2));
    di = norm(r)*cos(argLat)*acc(3)/h_angular;
    dO = norm(r)*sin(argLat)*acc(3)/(h_angular*sin(i));
    do = (1/e/norm(v))*(2*sin(nu)*acc(1) + (2*e+norm(r)/a*cos(nu))*acc(2)) - norm(r)*sin(argLat)*cos(i)*acc(3)/h_angular/sin(i);
    dnu = h_angular/norm(r)^2 - (1/e/norm(v))*(2*sin(nu)*acc(1) + (2*e+norm(r)/a*cos(nu))*acc(2));
    
    dy = [da,de,di,dO,do,dnu]';
end