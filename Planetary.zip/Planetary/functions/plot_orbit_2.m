function fig = plot_orbit_2(r1,r2)

%      plot_orbit.m - Orbit plotter
%     
%     PROTOTYPE:
%     	plot_orbit(r)
%     
%     DESCRIPTION:
%       Plot two orbits and Earth given the radius time series.
%     
%     INPUT:
%       r1[Nx3]      SC1 radius from the center of the planet [km]
%       r2[Nx3]      SC2 radius from the center of the planet [km]

%     OUTPUT:
%       plot        Orbit plot
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    plot3(r1(:,1),r1(:,2),r1(:,3),'r')
    hold on
    plot3(r2(:,1),r2(:,2),r2(:,3),'b')
    xlabel('rx');
    ylabel('ry');
    zlabel('rz');
    hold on
    [X,Y,Z] = sphere;
    r = 6378;
    X2 = X * r;
    Y2 = Y * r;
    Z2 = Z * r;
    surf(X2,Y2,Z2)
    axis equal
    legend('Orbit 1', 'Orbit 2','Earth')
end