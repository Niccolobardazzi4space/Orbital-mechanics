function [Re]=plot_earth()
%
%      plot_earth.m - Earth plotting.
%     
%     PROTOTYPE:
%     	Re = plot_earth
%     
%     DESCRIPTION:
%       Plots Earth globe.
%     
%     INPUT:
%       -
%     
%     OUTPUT:
%       Re [1]     Earth mean radius
%     
%     CALLED FUNCTIONS:
%       ------
% 
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
Re=6378.137;
TERRA=imread('planisphere.jpg','jpg');
props.FaceColor='texture';
props.EdgeColor='none';
props.FaceLighting='phong';
props.Cdata=TERRA;
C=[0;0;0];
[XX,YY,ZZ]=ellipsoid(C(1),C(2),C(3),Re,Re,Re,1000);
surface(-XX,-YY,-ZZ,props,'HandleVisibility','off');
end
