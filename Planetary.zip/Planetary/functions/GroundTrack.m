function [alpha,delta,lat,lon]=GroundTrack(r,green_lon0,t)
%
%      GroundTrack.m - Ground Track calculations
%     
%     PROTOTYPE:
%     	[alpha,delta,lat,lon]=GroundTrack(r,green_lon0,t)
%     
%     DESCRIPTION:
%       This function calculates the parameters of alpha, elevation, lat 
%       and lon in geographic coordinates.
%     
%     INPUT:
%       r[n,3]      Position with time of the SC [km].
%       green_lon0[1]   Longitude of Greenwhich meridian at start time 
%                       from the vernal equinox [deg]
%       t[n,1]      Time vector at which r was registered [s]
%     
%     OUTPUT:
%       alpha [n,1] Right ascension of the SC with the vernal equinox [deg].
%       delta [n,1] Declination of the SC with the equator [deg]
%       lat [n,1]   Latitude of the SC [deg]
%       lon [n,1]   Longitude of the SC [deg]
%     
%     CALLED FUNCTIONS:
%       -
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       

    T_day = 23*3600+56*60+4.0916; %1 sidereal day time
    rad2deg = 180/pi(); deg2rad = pi()/180; %Functions
    omega_E = 2*pi()/T_day; %Rotation speed of Earth (rad/s)
    green_lon = green_lon0*deg2rad;
    
    for i=1:length(t)
       radius = norm(r(i,:)); %gets modulus of r
       delta(i) = asin(r(i,3)/radius); %Declination in rad
       flag = r(i,2)/radius; %Calculates y/r. If y<0 means alpha>180º
       alpha(i) = acos(r(i,1)/radius/cos(delta(i)));
       if flag<0
           alpha(i) = 2*pi-alpha(i);
       end
       lon(i) = (alpha(i) - green_lon)*rad2deg; %Longitude in degrees
       if lon(i)<0
           lon(i) = 360-abs(lon(i));
       end
       lat(i) = delta(i)*rad2deg; %Latitude in degrees
       
       if i<length(t)
            green_lon = green_lon+omega_E*(t(i+1)-t(i)); %Updates for next iteration
            if green_lon>=2*pi()
                green_lon = green_lon-2*pi();
            end
       end
    end
end