function [dateV,orbital] = readTLE(mu)
%%
%      readTLE.m -- Read TLE file
%     
%     
%     DESCRIPTION:
%       This function reads a .txt file containing the TLEs of a satellite
%       and converts them in orbital parameters and dates
%     
%     INPUT: 
%          mu = planetary constant [km^3/s^2]
%       
%     
%     OUTPUT:
%          dateV [N,1]      vector of MATLAB dates 
%          orbital [N,6]    keplerian elements (a,e,i,Omega,omega,theta)
%     
%     CALLED FUNCTIONS:
%          keplerEq.m 
%          doy2date.m
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
%      

DATA = importdata('CHINASAT7_TLE_2000_2010.txt');
rows = length(DATA.textdata);
orbital = zeros(rows/2,6);
torb = zeros(rows/2,1);
yearV = zeros(rows/2,1);
doyV = zeros(rows/2,1);

for i = 1:rows/2
    cellorbital = DATA.textdata(i*2,3:7);
    orbital(i,1) = str2double(cell2mat(cellorbital(1)));
    orbital(i,2) = str2double(cell2mat(cellorbital(2)));
    orbital(i,3) = 1.e-7*str2double(cell2mat(cellorbital(3)));
    orbital(i,4) = str2double(cell2mat(cellorbital(4)));
    orbital(i,5) = DATA.data(2*i,1);
    orbital(i,5) = mu^(1/3)/(2*pi*orbital(i,5)/86400)^(2/3);
    M = str2double(cell2mat(cellorbital(5)));
    E = keplerEq(M,orbital(i,3),1.e-12);
    orbital(i,6) = rad2deg((2*atan(sqrt((1+orbital(i,3))/(1-orbital(i,3)))*tan(E/2)))+pi);
  
    torb(i) = 2000000 + str2double(cell2mat(DATA.textdata(i*2-1,4)));
    x = torb(i);
    y = num2str(x,16);
    yearV(i) = str2double(y(1:4));
    doyV(i) = str2double(y(5:end));

    if i>1
        if x == torb(i-1) 
            orbital(i,1) = NaN;
            orbital(i,2) = NaN;
            orbital(i,3) = NaN;
            orbital(i,4) = NaN;
            orbital(i,5) = NaN;
            orbital(i,6) = NaN;
            torb(i) = NaN;
            yearV(i) = NaN;
            doyV(i) = NaN;
        end
    end 
    
end

torb = torb(~isnan(torb));
orbital = orbital(~isnan(orbital));
orbital = reshape(orbital,length(torb),6);
yearV = yearV(~isnan(yearV));
doyV = doyV(~isnan(doyV));
[dateV] = doy2date(doyV,yearV);



