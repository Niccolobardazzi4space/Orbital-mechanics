function fig = Comet_orbit(r)
    fig = figure();
%     [X,Y,Z] = sphere;
%     r = 6378;
%     X2 = X * r;
%     Y2 = Y * r;
%     Z2 = Z * r;
%     surf(X2,Y2,Z2)
%     axis equal
%     hold on
    comet3(r(:,1),r(:,2),r(:,3),0.7)
    grid on
    xlabel('rx');
    ylabel('ry');
    zlabel('rz');
    legend('Orbit','Earth')
end