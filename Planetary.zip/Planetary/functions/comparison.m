function C = comparison(A,B)
%%
%     DESCRIPTION:
%       Function to filter parameters
%     
%     INPUT:
%       A            first comparison term
%       B            second comparison term
%
%     
%     OUTPUT:
%       C            struct with root mean square value,standard deviation,
%                    maximum error of orbital elements
%
%     CALLED FUNCTIONS:
%       ----
%     
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
 
C.a.rms = rms(A(:,2));
C.e.rms = rms(A(:,3));
C.i.rms = rms(A(:,4));
C.O.rms = rms(A(:,5));
C.o.rms = rms(A(:,6));

C.a.std = std(A(:,2));
C.e.std = std(A(:,3));
C.i.std = std(A(:,4));
A(:,5) = deg2rad(A(:,5));
A(:,5) = unwrap(A(:,5));
A(:,6) = deg2rad(A(:,6));
A(:,6) = unwrap(A(:,6));
B(:,5) = deg2rad(B(:,5));
B(:,5) = unwrap(B(:,5));
B(:,6) = deg2rad(B(:,6));
B(:,6) = unwrap(B(:,6));
C.o.std = std(A(:,5));
C.O.std = std(A(:,6));

C.a.maxerr = max(abs(B(:,2)-A(:,2)));
C.e.maxerr = max(abs(B(:,3)-A(:,3)));
C.i.maxerr = max(abs(B(:,4)-A(:,4)));
C.o.maxerr = max(abs(B(:,5)-A(:,5)));
C.O.maxerr = max(abs(B(:,6)-A(:,6)));





