function a = RGT(k,m,mu)
%
%      RGT.m - Repeated Ground Track calculation 
%     
%     PROTOTYPE:
%     	a = RGT(k,m,mu)
%     
%     DESCRIPTION:
%       This function calculates the semi-mayor axis for a given Ground Track Plot.
%     
%     INPUT:
%       k [1]   Satellite orbit until repetition [integer]
%       m [1]   Earth days until repetition [integer]
%       mu [1]  Earth mass parameter [km3/s2]
%     
%     OUTPUT:
%       a [1]   Semi-mayor axis of orbit [km]
%     
%     CALLED FUNCTIONS:
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    T_day = 23*3600+56*60+4.0916; %1 sidereal day time
    rad2deg = 180/pi(); deg2rad = pi()/180; %Functions
    omegaE = 2*pi()/T_day; %Rotation speed of Earth (rad/s)
%     omega_E = 7.2916e-5;
    a = (mu*(T_day*m/2/pi/k)^2)^(1/3);
end