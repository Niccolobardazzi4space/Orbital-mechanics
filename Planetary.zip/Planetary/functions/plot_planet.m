function fig = plot_planet(R)

%      plot_planet.m : computes the plot of a planet as a sphere
%     
%     
%     DESCRIPTION:

%           computes the plot of a planet as a sphere

%     INPUT: 
%           PLANET: texture of a planisphere of a planet
%            R = radius of the planet
%     
%     OUTPUT:
%           plot

%     CALLED FUNCTIONS:
%                       -----
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%      

    [X,Y,Z] = sphere;
    r = R;
    X2 = X * r;
    Y2 = Y * r;
    Z2 = Z * r;
    surf(X2,Y2,Z2)
end