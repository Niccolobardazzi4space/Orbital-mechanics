function [fig,fighandle] = paramplotsall(t,A,B,C,fig)
%%
%     DESCRIPTION:
%       This function plots the columns of A,B,C matrices
%     
%     INPUT:
%       t          Time analyzed for the parameters
%       A[:,6]     Matrix which contains all the parameters
%       fig        # of figure where parameters are plotted on
%     
%     OUTPUT:
%       fig        new # for the next figure 
%       fighandle  # of figure where the paramters are plotted on
%       plot

%     CALLED FUNCTIONS:
%      ----------

%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

settings;
fighandle = fig;

subplot(3,2,1), plot(t,A(:,1),t,B(:,1),t,C(:,1)),  grid on, ylabel('$a$ [km]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,2), plot(t,A(:,2),t,B(:,2),t,C(:,2)),  grid on, ylabel('$e$'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,3), plot(t,A(:,3),t,B(:,3),t,C(:,3)),  grid on, ylabel('$i$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,4), plot(t,A(:,4),t,B(:,4),t,C(:,4)), grid on, ylabel('$\Omega$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
% ylim([357 360])
subplot(3,2,5), plot(t,A(:,5),t,B(:,5),t,C(:,5)), grid on, ylabel('$\omega$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,6), plot(t,A(:,6),t,B(:,6),t,C(:,6)), grid on, ylabel('$\theta$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
fig = fig+1;
legend('Program','CHINASAT7','GMAT');
Lgnd = legend('show');
Lgnd.Position(1) = 0.75;
Lgnd.Position(2) = 0.88;
end

    function settings
        % Settings for the plots
        set(0,'defaulttextinterpreter','latex')
        set(0,'defaultlegendinterpreter','latex')
        set(0,'defaultAxesTickLabelInterpreter','latex')
        set(0,'DefaultTextFontSize',18)
        set(0,'DefaultAxesFontSize',14)
        set(0,'DefaultTextFontName','Times')
        set(0,'DefaultAxesFontName','Times')
        set(0,'DefaultLineLinewidth',1.2)
    end
    