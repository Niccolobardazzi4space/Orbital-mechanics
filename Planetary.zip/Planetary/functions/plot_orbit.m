function plot_orbit(r)
%
%      plot_orbit.m - Orbit plotter
%     
%     PROTOTYPE:
%     	plot_orbit(r)
%     
%     DESCRIPTION:
%       Plot an orbit given the radius time series.
%     
%     INPUT:
%       r[Nx3]      SC radius from the center of the planet [km]
%     
%     OUTPUT:
%       plot        Orbit plot
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    plot3(r(:,1),r(:,2),r(:,3),'LineWidth',2)
    set(gcf,'Units','normalized','OuterPosition',[0 0 1 1]);
    xlabel('rx');
    ylabel('ry');
    zlabel('rz');
end