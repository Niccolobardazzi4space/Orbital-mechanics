function dy = ode_orbit_J2Moon(t, y, mu, J2, Re, muM, MJD0)

%
%      ode_orbit_J2Moon.m - Two body problem equation
%     
%     PROTOTYPE:
%     	dy = ode_orbit_J2Moon( ~, y, mu,J2,Re,muM,MJD0)
%     
%     DESCRIPTION:
%       This function calculates the derivative of position and velocity of
%       the SC with time. Use for integration in a perturbed 2BP with J2
%       and Moon perturbations
%     
%     INPUT:
%       y[6,1]  Vector with position and velocity of the SC [km,km/s].
%       mu[1]   Planet constant [km^3/s^2]
%       J2      oblateness parameter for J2 effect
%       Re      Earth radius
%       muM     Moon constant [km^3/s^2];
%       MJD0    initial time condition in mjd2000 format
%     
%     OUTPUT:
%       dy[]    Vector with velocity and acceleration of the SC [km/s,km/s2].
%     
%     CALLED FUNCTIONS:
%       -ephMoon.m
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    r = y(1:3); v = y(4:6);

    %Compute J2 perturbation in ECEF
    a_vector_x = (y(1)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_y = (y(2)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_z = (y(3)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-3);
    aJ2 = [a_vector_x;a_vector_y;a_vector_z];
    aJ2 = aJ2*((3/2)*(J2*mu*Re^2)/norm(y(1:3))^4);
    
    %Compute moon perturbation in ECEF
    tdays = t/24/3600;
    MJD2000 = MJD0+tdays;
    [rM, ~] = ephMoon(MJD2000); rM = rM';
    aM = muM/norm(rM)^3*(-r+3*(dot(rM,r)/norm(rM)^2)*rM);
    
    %Calculate orbital
    dy = [v;(-mu/norm(r)^3)*r+aJ2+aM];
end