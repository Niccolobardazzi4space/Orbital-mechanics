function E = keplerEq(M,e,eps)
%     DESCRIPTION:
%       This function reads a .txt file containing the TLEs of a satellite
%       and converts them in orbital parameters and dates
%     
%     INPUT: 
%          M       mean anomaly
%          e       eccentricity
%          eps     tolerance
%       
%     
%     OUTPUT:
%          E       eccentric anomaly
%     
%     CALLED FUNCTIONS:
%          -----
%
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%       
En  = M;
Ens = En - (En-e*sin(En)- M)/(1 - e*cos(En));
while ( abs(Ens-En) > eps )
    En = Ens;
    Ens = En - (En - e*sin(En) - M)/(1 - e*cos(En));
end
E = Ens;

end