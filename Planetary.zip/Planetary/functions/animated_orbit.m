function animated_orbit(r,CometPoints,axis3d,t,green_lon0)
%
%      animated_orbit.m - Orbit video
%     
%     PROTOTYPE:
%     	animated_orbit(r,CometPoints,axis3d,t,green_lon0)
%     
%     DESCRIPTION:
%       This function makes a video of the orbit followed by the satellite.
%     
%     INPUT:
%       r [N,3]             Spacecraft position in N times [km]
%       CometPoints [1]     Points for maintain graph after point [integer]
%       axis3d [1,3]        Axis handle
%       t [N,1]             Times at which r is calculated [s]
%       green_lon0 [1]      Longitude of Greenwhich meriadiat at initial
%                           time compared to the vernal equinox [deg]
%     
%     OUTPUT:
%       -
%     
%     CALLED FUNCTIONS:
%       create_customEarth
%       create_rotatingEarth
%    
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    globe = create_customEarth(green_lon0);
    comet=CometPoints;
    curve = animatedline('LineWidth',2,'Color','r','MaximumNumPoints',comet);
    set(gca,'Xlim',axis3d(1,:),'Ylim',axis3d(2,:),'Zlim',axis3d(3,:));
    grid minor
    xlabel('rx');
    ylabel('ry');
    zlabel('rz');
    view(43,24);
    title('Orbit Plot')
    set(gcf,'Units','normalized','OuterPosition',[0 0 1 1]);
    hold on
    delete(globe)
    for ii=1:length(r(:,1))
        globe = create_rotatingEarth(t(ii),green_lon0);
        addpoints(curve,r(ii,1),r(ii,2),r(ii,3));
        head = scatter3(r(ii,1),r(ii,2),r(ii,3),'filled','MarkerFaceColor','b','MarkerEdgeColor','b');
        drawnow;
        F(ii) = getframe(gcf);
        if ii>1
            pause((t(ii)-t(ii-1))*1e-7);
        else
            pause(0.01)
        end
        delete(head);
        delete(globe)
    end
    
    video = VideoWriter('Orbit.avi','Uncompressed AVI');
    video.FrameRate = 60;
    open(video)
    writeVideo(video,F)
    close(video)
end