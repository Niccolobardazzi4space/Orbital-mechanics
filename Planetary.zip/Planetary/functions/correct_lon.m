function [lon_corrected,lat_corrected,varargout] = correct_lon(lon,lat,varargin)
%
%      correct_lon.m - Lon and lat corrections for plotting.
%     
%     PROTOTYPE:
%     	[lon_corrected,lat_corrected,t_corrected] = correct_lon(lon,lat,t)
%     
%     DESCRIPTION:
%       This function corrects lat and lon to avoind jumps in plotting, 
%       introducing NaN values whenever a jump occurs.
%     
%     INPUT:
%       lat [n,1]   Latitude of the SC [deg]
%       lon [n,1]   Longitude of the SC [deg]
%       t[n,1]      Time vector for lat and lon [s] [OPTIONAL]
%     
%     OUTPUT:
%       lat_corrected [N,1]     Latitude of the SC corrected to avoid jumps [deg]
%       lon_corrected [N,1]     Longitude of the SC corrected to avoid jumps [deg]
%       t_corrected [N,1]       Time vector corrected to match lat, lon in
%                               video representation
%     
%     CALLED FUNCTIONS:
%       -
% 
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

lon = wrapTo180(lon);
    if size(varargin)<1
        for i=2:length(lon)
            if abs(lon(i)-lon(i-1))>100
                if lon(i)<0
                    lon = [lon(1:i-1),lon(i)+360,NaN,lon(i-1)-360,lon(i:end)];
                else
                    lon = [lon(1:i-1),lon(i)-360,NaN,lon(i-1)+360,lon(i:end)];
                end
                lat = [lat(1:i-1),lat(i),NaN,lat(i-1),lat(i:end)];
                i = i+4;
            end
        end
        lon_corrected = lon;
        lat_corrected = lat;
        
    else
        t = cell2mat(varargin);
        for i=2:length(lon)
            if abs(lon(i)-lon(i-1))>100
                if lon(i)<0
                    lon = [lon(1:i-1),lon(i)+360,NaN,lon(i-1)-360,lon(i:end)];
                else
                    lon = [lon(1:i-1),lon(i)-360,NaN,lon(i-1)+360,lon(i:end)];
                end
                lat = [lat(1:i-1),lat(i),NaN,lat(i-1),lat(i:end)];
                t = [t(1:i-1);t(i);NaN;t(i-1);t(i:end)];
                i = i+4;
            end
        end
        lon_corrected = lon;
        lat_corrected = lat;
        varargout{1} = t;
        
    end
end