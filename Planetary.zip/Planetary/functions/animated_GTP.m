function animated_GTP(lat,lon,CometPoints,t)
%
%      animated_GTP.m - GTP video
%     
%     PROTOTYPE:
%     	animated_GTP(lat,lon,CometPoints,t)
%     
%     DESCRIPTION:
%       This function makes a video of the Ground Track followed by the satellite.
%     
%     INPUT:
%       lat [N,1]   Latitude of the SC (already corrected) by correct_lon [deg]
%       lon [N,1]   Longitude of the SC (already corrected) by correct_lon [deg]
%       CometPoints [1]     Points for maintain graph after point [integer]
%       t [N,1]             Times at which r is calculated [s]
%     
%     OUTPUT:
%       -
%     
%     CALLED FUNCTIONS:
%       -
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.  


    xlim([-180,180]);ylim([-90,90]);
    grid minor; box on;
    xlabel('Longitude [º]'); ylabel('Latitude [º]');
    hold on
    I = imread('EarthTexture.jpg'); 
    h = image(xlim,-ylim,I); 
    uistack(h,'bottom')
    set(gcf,'Units','normalized','OuterPosition',[0 0 1 1]);
    comet=CometPoints;
    curve = animatedline('LineWidth',2,'Color','r','MaximumNumPoints',comet);
    hold on
        for ii=1:length(lat)
            addpoints(curve,lon(ii),lat(ii));
            head = scatter(lon(ii),lat(ii),'filled','MarkerFaceColor','y','MarkerEdgeColor','y');
            drawnow;
            F(ii) = getframe(gcf);
            if ii>1
                pause((t(ii)-t(ii-1))*1e-6);
            else
                pause(0.01)
            end
            delete(head);
        end
        
    GTPvideo = VideoWriter('GTP.avi','Uncompressed AVI');
    GTPvideo.FrameRate = 60;
    open(GTPvideo)
    writeVideo(GTPvideo,F)
    close(GTPvideo)
end