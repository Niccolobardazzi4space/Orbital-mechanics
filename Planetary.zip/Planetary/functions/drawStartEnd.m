function drawStartEnd(start,last,c)
%
%      drawStartEnd.m - Draws beginning and ending point for GTP
%     
%     PROTOTYPE:
%     	drawStartEnd(start,last,c)
%     
%     DESCRIPTION:
%       This function plot the GTP.
%     
%     INPUT:
%       start [1,2]     Start point in [Lon,Lat] [deg]
%       end [1,2]       End point in [Lon,Lat] [deg]
%     
%     OUTPUT:
%       plot
%     
%     CALLED FUNCTIONS:
%       -
% 
%     LAST UPDATED:
%      18/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    hold on
    scatter(start(1),start(2),170,'o','MarkerEdgeColor',c,'LineWidth',3);
    hold on
    scatter(last(1),last(2),170,'s','MarkerEdgeColor',c,'LineWidth',3);
end