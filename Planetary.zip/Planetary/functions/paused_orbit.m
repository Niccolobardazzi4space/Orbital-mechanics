function fig = animated_orbit(r)


    fig_21 = figure(21);
    curve = animatedline('LineWidth',2);
    set(gca,'Xlim',[-1e4,4.5e4],'Ylim',[-2e4,2e4],'Zlim',[-7e3,7e3]);
    grid minor
    xlabel('rx');
    ylabel('ry');
    zlabel('rz');
    view(43,24);
    hold on
    [X,Y,Z] = sphere;
    r = 6378;
    X2 = X * r;
    Y2 = Y * r;
    Z2 = Z * r;
    surf(X2,Y2,Z2)
    axis equal
    hold on
    for ii=1:length(r(:,1))
        addpoints(curve,r(ii,1),r(ii,2),r(ii,3));
        head = scatter3(r(ii,1),r(ii,2),r(ii,3));
        drawnow;
        pause(0.001);
        delete(head);
    end
    legend('Orbit','Earth')
end