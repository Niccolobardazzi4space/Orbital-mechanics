function [elements,orb_filt] = movfilterchina(orb,t,n)
%%
%     DESCRIPTION:
%       Function to filter parameters
%     
%     INPUT:
%       orb[:,6]    Results that need to be filtered:
%       t           Time of interest for the results
%       n           Number of points of interpolation for filtering action 
%
%     
%     OUTPUT:
%       elements    orbital elements rearranged from rad-->deg
%       orb_filt    filtered results
%   
%     
%     DESCRIPTION:
%       This function calculates the derivative of orbital elements of
%       the SC with time considering J2 perturbation and Moon as third body.
%       Use for integration.
%     
%     CALLED FUNCTIONS:
%       
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%   

x = linspace(t(1),t(end),n); 

orb(:,3) = deg2rad(orb(:,3));
orb(:,4) = deg2rad(orb(:,4));
orb(:,5) = deg2rad(orb(:,5));
orb(:,6) = deg2rad(orb(:,6));

orb(:,3) = unwrap(orb(:,3));
orb(:,4) = unwrap(orb(:,4));
orb(:,5) = unwrap(orb(:,5));
orb(:,6) = unwrap(orb(:,6));

% interpolation
a_interp = interp1(t,orb(:,1),x);
ecc_interp = interp1(t,orb(:,2),x);
incl_interp = interp1(t,orb(:,3),x);
RAAN_interp = interp1(t,orb(:,4),x); 
AoP_interp = interp1(t,orb(:,5),x); 
TA_interp = interp1(t,orb(:,6),x); 

% filtering by points
a_filt = movmean(a_interp,300);
ecc_filt = movmean(ecc_interp,100);
incl_filt = movmean(incl_interp,100);
RAAN_filt = movmean(RAAN_interp,100); 
AoP_filt = movmean(AoP_interp,100);

% deg filter output
TA_interp = rad2deg(TA_interp);
incl_filt = rad2deg(incl_filt);
AoP_filt  = rad2deg(AoP_filt );
RAAN_filt = rad2deg(RAAN_filt);
RAAN_filt = wrapTo360(real(RAAN_filt));
incl_filt = wrapTo360(incl_filt);
AoP_filt  = wrapTo360(real(AoP_filt));
TA_filt = wrapTo360(TA_interp);

% deg orbital output
orb(:,3) = rad2deg(orb(:,3));
orb(:,4) = rad2deg(orb(:,4));
orb(:,5) = rad2deg(orb(:,5));
orb(:,6) = rad2deg(orb(:,6));
orb(:,3) = wrapTo360(orb(:,3));
orb(:,4) = wrapTo360(orb(:,4));
orb(:,5) = wrapTo360(orb(:,5));
orb(:,6) = wrapTo360(orb(:,6));

elements = orb;
orb_filt = [x',a_filt',ecc_filt',incl_filt',RAAN_filt',AoP_filt',TA_filt'];

end