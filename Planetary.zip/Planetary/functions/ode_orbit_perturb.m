function dy = ode_orbit_perturb( ~, y, mu, J2, Re)
%
%      ode_orbit_perturb.m - Two body problem equation
%     
%     PROTOTYPE:
%     	dy = ode_orbit_perturb( ~, y, mu)
%     
%     DESCRIPTION:
%       This function calculates the derivative of position and velocity of
%       the SC with time considering J2 perturbation. Use for integration.
%     
%     INPUT:
%       y[6,1]  Vector with position and velocity of the SC [km,km/s].
%       mu[1]   Planet constant [km3/s2]
%       J2[1]   Planet oblateness parameter.
%       Re[1]   Planet mean radius [km]
%     
%     OUTPUT:
%       dy[]    Vector with velocity and acceleration of the SC [km/s,km/s2].
%     
%     CALLED FUNCTIONS:
%       -
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.


    a_vector_x = (y(1)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_y = (y(2)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-1);
    a_vector_z = (y(3)/norm(y(1:3)))*(5*y(3)^2/norm(y(1:3))^2-3);
    aJ2 = [a_vector_x;a_vector_y;a_vector_z];
    aJ2 = aJ2*((3/2)*(J2*mu*Re^2)/norm(y(1:3))^4);
    dy = [y(4:6);(-mu/norm(y(1:3))^3)*y(1:3)+aJ2];
end