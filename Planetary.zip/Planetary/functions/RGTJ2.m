function a = RGTJ2(k,m,mu,a0,J2,Re,e,i)
%
%       RGTJ2.m - Repeated Ground Track calculation with J2
%     
%     PROTOTYPE:
%     	a = RGTJ2(k,m,mu,a0,J2,Re,e,i)
%     
%     DESCRIPTION:
%       This function calculates the semi-mayor axis for a given Ground Track Plot.
%     
%     INPUT:
%       k [1]   Satellite orbit until repetition [integer]
%       m [1]   Earth days until repetition [integer]
%       mu [1]  Earth mass parameter [km3/s2]
%       a0 [1]  Initial sma for iteration (preferably from RGT) [km]
%       J2 [1]  Earth oblateness parameter
%       Re [1]  Earth mean radius [km]
%       e [1]   Eccentricity [rad]
%       i [1]   Inclination
%     
%     OUTPUT:
%       a [1]   Semi-mayor axis of orbit [km]
%     
%     CALLED FUNCTIONS:
%
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.

    
    T_day = 23*3600+56*60+4.0916;               % 1 sidereal day time
    rad2deg = 180/pi(); deg2rad = pi()/180;     % Functions
    omegaE = 2*pi()/T_day;                      % Rotation speed of Earth (rad/s)
    aRGT0 = a0;              % Initial sma of the orbit
    options = optimoptions('fsolve','Display','off','FunctionTolerance',1e-16,'OptimalityTolerance',1e-16);
%     options = optimset('Display','off','FunValCheck','on');
    aRGT = fsolve(@(aRGT) fGTP(aRGT,mu,J2,Re,e,i,omegaE,k,m),aRGT0,options);
%    aRGT = fzero(@(aRGT) fGTP(aRGT,mu,J2,Re,e,i,omegaE,k,m),aRGT0,options);
    a = aRGT;
end
function F = fGTP(a,mu,J2,Re,e,i,omegaE,k,m)
    coef = 3*sqrt(mu)*J2*Re^2/(2*(1-e^2)^2*a^(7/2));
    Omega_dot = -coef*cos(i);
    omega_dot = -coef*(5/2*sin(i)^2-2);
    M0_dot = -coef*(1-3/2*sin(i)^2);
    n = (k/m)*(omegaE-Omega_dot)-omega_dot-M0_dot;
    F = (mu/n^2)^(1/3)-a;
end