function overfiltplots(A_filt,fighandle)
%%
%     DESCRIPTION:
%       This function plots the filtered results over the real outputs
%     
%     INPUT:
%       A_filt[:,7]     Matrix which contains all the filtered results
%       fighandle       # of figure where real outputs are plotted on
%     
%     OUTPUT:
%       plot
%

figure(fighandle);
for i=1:6
    h=subplot(3,2,i);
    hold on
    plot(A_filt(:,1),A_filt(:,i+1),'k');
end
legend('Output','Filtered');
Lgnd = legend('show');
Lgnd.Position(1) = 0.75;
Lgnd.Position(2) = 0.88;
h=subplot(3,2,4); 
% ylim([355,360]);
end