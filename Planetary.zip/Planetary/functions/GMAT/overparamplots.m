function overparamplots(B,fighandle)
%%
%     DESCRIPTION:
%       This function plots the columns of B matrix over an existing figure
%     
%     INPUT:
%       B[:,6]     Matrix which contains all the parameters
%       fig        # of figure where parameters are plotted on
%     
%     OUTPUT:
%       fighandle  # of figure where the other paramters are plotted on
%       plot
%
figure(fighandle);
j = 3;
for i=1:6
    h=subplot(3,2,i);
    hold on
    plot(B(:,1),B(:,j),'r');
    j = j+1;
end
h=subplot(3,2,4); ylim([355,360]);
end