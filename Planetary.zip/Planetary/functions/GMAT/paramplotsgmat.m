function [fig,fighandle] = paramplotsgmat(A,fig)
%%
%     DESCRIPTION:
%       This function plots the columns of A matrix from GMAT
%     
%     INPUT:
%       A[:,8]     Matrix which contains the time vector plus all the parameters
%       fig        # of figure where parameters are plotted on
%     
%     OUTPUT:
%       fig        new # for the next figure 
%       fighandle  # of figure where the paramters are plotted on
%       plot
%
settings;
fighandle = fig;
t = A(:,1); %Time in days
a = A(:,3); e = A(:,4); i = A(:,5); RAAN = A(:,6); AoP = A(:,7); TA = A(:,8);

sgtitle('Orbital states') 

subplot(3,2,1), plot(t, a),  grid on, ylabel('$a$ [km]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,2), plot(t, e),  grid on, ylabel('$e$'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,3), plot(t, i),  grid on, ylabel('$i$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,4), plot(t, RAAN), grid on, ylabel('$\Omega$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,5), plot(t, AoP), grid on, ylabel('$\omega$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,6), plot(t, TA), grid on, ylabel('$\theta$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
fig = fig+1;
end

    function settings
        % Settings for the plots
        set(0,'defaulttextinterpreter','latex')
        set(0,'defaultlegendinterpreter','latex')
        set(0,'defaultAxesTickLabelInterpreter','latex')
        set(0,'DefaultTextFontSize',18)
        set(0,'DefaultAxesFontSize',14)
        set(0,'DefaultTextFontName','Times')
        set(0,'DefaultAxesFontName','Times')
        set(0,'DefaultLineLinewidth',1.2)
    end