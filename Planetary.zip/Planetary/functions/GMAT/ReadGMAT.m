function [orb_filt,fig] = ReadGMAT(fig,times)

filename = 'OP_J2Moon_China.txt';
DATA = importdata(filename);
A = DATA.data;
% figure(fig);
% [fig,fighandle] = paramplotsgmat(A,fig);

% filename = 'OP_J2.txt';
% B = importdata(filename);
% overparamplots(B,fighandle)

figure(fig)
t = linspace(times(1),times(2),length(A));
orb = A(:,3:8);
n = 1000;
[orb,orb_filt] = movfilterchina(orb,t,n);
[~,fighandle] = paramplots(t,orb,fig);
overfiltplots(orb_filt,fighandle)

hold on
fig = fig+1;
% plot(x,A_filt,'--k');
