function [fig,fighandle] = paramplots(t,A,fig)
%%
%     DESCRIPTION:
%       This function plots the columns of A matrix
%     
%     INPUT:
%       t          Time analyzed for the parameters
%       A[:,6]     Matrix which contains all the parameters
%       fig        # of figure where parameters are plotted on
%     
%     OUTPUT:
%       fig        new # for the next figure 
%       fighandle  # of figure where the paramters are plotted on
%       plot
%

settings;
fighandle = fig;
a = A(:,1); e = A(:,2); i = A(:,3); RAAN = A(:,4); AoP = A(:,5); TA = A(:,6);

subplot(3,2,1), plot(t, a),  grid on, ylabel('$|a_{G}-a_{rv}|$ [km]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,2), plot(t, e),  grid on, ylabel('$|e_{G}-e_{rv}|$'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,3), plot(t, i),  grid on, ylabel('$|i_{G}-i_{rv}|$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,4), plot(t, RAAN), grid on, ylabel('$|\Omega_{G}-\Omega_{rv}|$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
subplot(3,2,5), plot(t, AoP), grid on, ylabel('$|\omega_{G}-\omega_{rv}|$ [deg]'), xlabel('$t$ [days]')
xlim([t(1) t(end)])
% subplot(3,2,6), plot(t, TA), grid on, ylabel('$|\theta_{G}-\theta{rv}|$ [deg]'), xlabel('$t$ [days]')
% xlim([t(1) t(end)])
fig = fig+1;
end

    function settings
        % Settings for the plots
        set(0,'defaulttextinterpreter','latex')
        set(0,'defaultlegendinterpreter','latex')
        set(0,'defaultAxesTickLabelInterpreter','latex')
        set(0,'DefaultTextFontSize',18)
        set(0,'DefaultAxesFontSize',14)
        set(0,'DefaultTextFontName','Times')
        set(0,'DefaultAxesFontName','Times')
        set(0,'DefaultLineLinewidth',1.2)
    end