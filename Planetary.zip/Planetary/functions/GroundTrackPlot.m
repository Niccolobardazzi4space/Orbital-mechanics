function GroundTrackPlot(lat,lon)
%
%      GroundTrackPlot.m - Ground Track plotting
%     
%     PROTOTYPE:
%     	GroundTrackPlot(lat,lon)
%     
%     DESCRIPTION:
%       This function plot the GTP.
%     
%     INPUT:
%       lat [N,1]   Latitude of the SC (already corrected) by correct_lon [deg]
%       lon [N,1]   Longitude of the SC (already corrected) by correct_lon [deg]
%     
%     OUTPUT:
%       plot
%     
%     CALLED FUNCTIONS:
%       drawStartEnd
% 
%      GaussJ2Moon.m - Gauss planetary equations with Moon and J2
%     
%     DESCRIPTION:
%       This function calculates the derivative of orbital elements of
%       the SC with time considering J2 perturbation and Moon as third body.
%       Use for integration.
%     
%     INPUT:
%       t [1]   Time
%       y [1,6] [a,e,i,O,o,nu] orbital elements of orbit
%       mu[1]   Planet constant [km3/s2]
%       J2[1]   Planet oblateness parameter.
%       Re[1]   Planet mean radius [km]
%       muM [1] Moon mass parameter [km3/s2]
%       MJD0 [1]Date equivalent to time zero in MJD2000 [days]
%     
%     OUTPUT:
%       dy[]    d[a,e,i,O,o,nu]dt Vector with derivative of orbital 
%               elements of the SC [km/2,1/s,rad/s,rad/s,rad/s,rad/s].
%     
%     CALLED FUNCTIONS:
%            ----------
%     LAST UPDATED:
%      20/01/2020
%
%     CREATED BY:
%      Bardazzi N., Carcano S., Domaschio J., Maestro Martinez J.D.
%   
    set(gcf,'Units','normalized','OuterPosition',[0 0 1 1]);
    plot(lon,lat,'r','LineWidth',1.5);
    drawStartEnd([lon(1),lat(1)],[lon(end),lat(end)],'r')
    xlim([-180,180]);ylim([-90,90]);
    grid minor; box on;
    xlabel('Longitude [deg]'); ylabel('Latitude [deg]');
    hold on
    I = imread('EarthTexture.jpg'); 
    h = image(xlim,-ylim,I); 
    uistack(h,'bottom')
    set(gca,'FontSize',15)
end